package com.test.view;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.test.dao.ParentDAO;



/**
 * Servlet implementation class DisplayAllParents
 */
@WebServlet("/DisplayAllParents")
public class DisplayAllParents extends HttpServlet {
	private static final long serialVersionUID = 1L;

    /**
     * @see HttpServlet#HttpServlet()
     */
    public DisplayAllParents() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	PrintWriter out=response.getWriter();
   try{
	ResultSet rs=ParentDAO.DisplayAll();
     out.println("<html><head><link rel='stylesheet' type='text/css' href='home2/css/bootstrap.min.css'></head>");
     //out.println("<a href=ParentInterface class='btn btn-primary'>Add New Record</a>");
   if(rs.next())
   {out.println("<table class='table table-bordered'");
    out.println("<tr><th>Id<br>Name</th><th>DOB<br>We are student's</th><th>Address</th><th>Contact</th><th>Admission<br>Qualification</th><th>Photograph</th><th>Update</th></tr>");
    do
    { String g="";
    	if(rs.getString(5).equals("Parents"))
    	{g=" f/o ";}
    	else
    	{g=" g/o ";}

    out.println("<tr><td>"+rs.getString(1)+"<br>"+rs.getString(2)+g+rs.getString(3)+"</td><td>"+rs.getString(4)+"<br>"+rs.getString(5)+"</td><td>"+rs.getString(6)+"<br>"+rs.getString(8)+","+rs.getString(7)+"</td><td>Landline:"+rs.getString(9)+"<br>Mobile:"+rs.getString(10)+"<br>"+rs.getString(11)+"</td><td>"+rs.getString(12)+"<br>"+rs.getString(13)+"</td><td><img src=pic/"+rs.getString(15)+" width=50 height=50><br></td><td><a href=UpdateDeleteParent?pid="+rs.getString(1)+" class='btn btn-info'>Edit/Delete</a></td></tr>");


    }while(rs.next());
	   rs.close();
	   out.println("</table>");
   }
   else
   {
	out.println("Record Not Found..");
   }
    out.println("</html>");
   }catch(Exception e)
   {out.println(e);

   }
	}

}

