package com.test.dao;



import java.sql.Connection;
import java.sql.DriverManager;

import java.sql.ResultSet;


import com.test.model.Teacher;



public class TeacherDAO {
	static String provider="jdbc:mysql://localhost:3306/StudentInfo";
 public static boolean AddNewRecord(Teacher T)
 { try{
	 Class.forName("com.mysql.jdbc.Driver").newInstance();   
	 Connection cn=DriverManager.getConnection(provider,"root","123");
  String query="insert into teachers values('"+T.getTeacherid()+"','"+T.getTeachername()+"','"+T.getBirthdate()+"','"+T.getGender()+"','"+T.getAddress()+"','"+T.getState()+"','"+T.getCity()+"','"+T.getContactnumber()+"','"+T.getMobilenumber()+"','"+T.getEmailid()+"','"+T.getDateofjoining()+"','"+T.getQualification()+"','"+T.getDesignation()+"','"+T.getPassword()+"','"+T.getPhotograph()+"','"+T.getBranch()+"')";
  System.out.println(query);
  
  
  boolean st=DBHelper.executeUpdate(cn, query);
  return st;
}catch(Exception e)
{System.out.println(e);
	 return false;
}}

 public static ResultSet DisplayAllTeacher()
 { try{
	 Class.forName("com.mysql.jdbc.Driver").newInstance();   
	 Connection cn=DriverManager.getConnection(provider,"root","123");
  String query="select * from teachers";
  ResultSet rs=DBHelper.executeQuery(cn, query);
  return rs;
	 
	 
 }catch(Exception e)
 {System.out.println(e);
	 return null;
 }}
 
 

 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 

 public static ResultSet DisplayById(String tid)
 { try{
	 Class.forName("com.mysql.jdbc.Driver").newInstance();   
	 Connection cn=DriverManager.getConnection(provider,"root","123");
  String query="select * from teachers where tid='"+tid+"'";
  ResultSet rs=DBHelper.executeQuery(cn, query);
  return rs;
	 
	 
 }catch(Exception e)
 {System.out.println(e);
	 return null;
 }}

 public static boolean DeleteById(String tid)
 { try{
	 Class.forName("com.mysql.jdbc.Driver").newInstance();   
	 Connection cn=DriverManager.getConnection(provider,"root","123");
  String query="delete from teachers where tid='"+tid+"'";
   
  boolean st=DBHelper.executeUpdate(cn, query);
    return st;
 }catch(Exception e)
 {System.out.println(e);
	 return false;
 }}
 public static boolean EditById(Teacher T)
 { try{
	 Class.forName("com.mysql.jdbc.Driver").newInstance();   
	 Connection cn=DriverManager.getConnection(provider,"root","123");
  String query="update teachers set tname='"+T.getTeachername()+"',tdob='"+T.getBirthdate()+"',tgen='"+T.getGender()+"',tadd='"+T.getAddress()+"',tstate='"+T.getState()+"',tcity='"+T.getCity()+"',tcon='"+T.getContactnumber()+"',tmbl='"+T.getMobilenumber()+"',tmail='"+T.getEmailid()+"',tdoj='"+T.getDateofjoining()+"',tqua='"+T.getQualification()+"',tdes='"+T.getDesignation()+"' where tid='"+T.getTeacherid()+"'";
  System.out.println(query);   
  boolean st=DBHelper.executeUpdate(cn, query);
  if(!T.getPhotograph().equals(""))
  {
	query="update teachers set tpic='"+T.getPhotograph()+"' where tid='"+T.getTeacherid()+"'";
	st=DBHelper.executeUpdate(cn, query);
  }
    return st;
 }catch(Exception e)
 {System.out.println(e);
	 return false;
 }}

 public static boolean AddMidTermMarks(String id,String s1,String s2,String s3,String s4,String s5)
 { try{
	 Class.forName("com.mysql.jdbc.Driver").newInstance();   
	 Connection cn=DriverManager.getConnection(provider,"root","123");
  String query="insert into midtermmarks values('"+id+"','"+s1+"','"+s2+"','"+s3+"','"+s4+"','"+s5+"')";
  System.out.println(query);
  
  
  boolean st=DBHelper.executeUpdate(cn, query);
  return st;
}catch(Exception e)
{System.out.println(e);
	 return false;
}}
 public static ResultSet DisplaySubjects(String branch)
 { try{
	 Class.forName("com.mysql.jdbc.Driver").newInstance();   
	 Connection cn=DriverManager.getConnection(provider,"root","123");
  String query="select * from subject where branch='"+branch+"'";
  System.out.println(query);
  
  
  ResultSet rs=DBHelper.executeQuery(cn, query);
  return rs;

}catch(Exception e)
{System.out.println(e);
	 return null;
}}

 
public static Teacher CheckPassword(String tid, String tpass) {
	// TODO Auto-generated method stub
	 { 	
			try{
			 Class.forName("com.mysql.jdbc.Driver").newInstance();   
			 Connection cn=DriverManager.getConnection(provider,"root","123");
		  String query="select * from teachers where tid='"+tid+"' and tpass='"+tpass+"'";
		   ResultSet rs=DBHelper.executeQuery(cn, query);
		   if(rs.next())
		   {
			   Teacher T=new Teacher();
			   T.setTeacherid(rs.getString(1));
			   T.setTeachername(rs.getString(2));
			   T.setPhotograph(rs.getString(15));
			   T.setBranch(rs.getString(16));
			   return(T);
			   
		   }
		   
		    return null;
		 }catch(Exception e)
		 {System.out.println(e);
			 return null;


		}
		 }
}

public static ResultSet DisplayMarks() {
	// TODO Auto-generated method stub
	 try{
		 Class.forName("com.mysql.jdbc.Driver").newInstance();   
		 Connection cn=DriverManager.getConnection(provider,"root","123");
	  String query="select * from marks";
	  ResultSet rs=DBHelper.executeQuery(cn, query);
	  return rs;
		 
		 
	 }catch(Exception e)
	 {System.out.println(e);
		 return null;
	 }}

public static boolean AddQuizMarks(String id,String s1,String s2,String s3,String s4,String s5)
 { try{
	 Class.forName("com.mysql.jdbc.Driver").newInstance();   
	 Connection cn=DriverManager.getConnection(provider,"root","123");
  String query="insert into quizmarks values('"+id+"','"+s1+"','"+s2+"','"+s3+"','"+s4+"','"+s5+"')";
  System.out.println(query);
  
  
  boolean st=DBHelper.executeUpdate(cn, query);
  return st;
}catch(Exception e)
{System.out.println(e);
	 return false;
}}


public static boolean AddMainSemMarks(String id,String s1,String s2,String s3,String s4,String s5)
{ try{
	 Class.forName("com.mysql.jdbc.Driver").newInstance();   
	 Connection cn=DriverManager.getConnection(provider,"root","123");
 String query="insert into mainsemmarks values('"+id+"','"+s1+"','"+s2+"','"+s3+"','"+s4+"','"+s5+"')";
 System.out.println(query);
 
 
 boolean st=DBHelper.executeUpdate(cn, query);
 return st;
}catch(Exception e)
{System.out.println(e);
	 return false;
}}
}