package com.test.view;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.test.dao.QueryDAO;

/**
 * Servlet implementation class ListOfqueries
 */
@WebServlet("/ListOfqueries")
public class ListOfqueries extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ListOfqueries() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		HttpSession ses=request.getSession();
		
		PrintWriter out=response.getWriter();
		try{
		       out.println("<html>");
		       out.println("<head><link rel='stylesheet' type='text/css' href='home2/css/bootstrap.min.css'></head>");
		       String tid=ses.getValue("TEID").toString();
		       ResultSet rs=QueryDAO.displayTeacherQueries(tid);
		       if(rs.next())
		       {
		    	   
			       out.println("<caption><b><i><h1>List of Queries</h1></i></b></caption><table class='table table-bordered'>");
			       
			       do
			       {
			    	   
			    	   out.println("<tr><td>Query ID:"+rs.getString(1)+"."+rs.getString(5).toUpperCase()+"</td></tr>");
			    	   String q=rs.getString(5).replace(" ","+");
			    	   out.println("<tr><td><a href=QueryAnswerInterface?qid="+rs.getString(1)+"&sid="+rs.getString(3)+"&que="+q+">"+rs.getString(6)+"</a></td></tr>");
			    	   
			       }while(rs.next());
			       out.println("</table>");
		       }
		       else
		       {
		    	 out.println("<b><i>No Queries Available !!!</i></b>");  
		       }
		       out.println("</html>");
		       out.flush();
		      }catch(Exception e){}
		
	}

}
