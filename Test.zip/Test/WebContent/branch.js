 $(document).ready(
        function() {

        	 $.getJSON("FetchBranchJSON", function(json){
        		 
                 $('#bn').empty();
                 $('#bn').append($('<option>').text("Select"));
                 $.each(json, function(i, item){
                         $('#bn').append($('<option>').text(item.BRANCHNAME).attr('value', item.BRANCHID));
                 });
            
        }); 
       
 
 $("#bn").change(function(){
 	$.getJSON("FetchAllSemesterByBranchIdJSON",{sid:$('#bn').val()}, function(json){
         $('#sem').empty();
         $('#sem').append($('<option>').text("Select"));
         $.each(json, function(i, item){
                 $('#sem').append($('<option>').text(item.SEMESTERNO).attr('value', item.SEMESTERID));
         });
     }); 
 	
 	$("#sem").change(function(){
 	 	$.getJSON("FetchAllSubIdBySemIdJSON",{sno:$('#sem').val()}, function(json){
 	         $('#si').empty();
 	         $('#si').append($('<option>').text("Select"));
 	         $.each(json, function(i, item){
 	                 $('#si').append($('<option>').text(item.SUBJECTNO).attr('value', item.SUBJECTID));
 	         });
 	     }); 
 	 	$("#si").change(function(){
 	 	 	$.getJSON("FetchAllSubNameBySubIdJSON",{sna:$('#si').val()}, function(json){
 	 	         $('#sn').empty();
 	 	         $('#sn').append($('<option>').text("Select"));
 	 	         $.each(json, function(i, item){
 	 	                 $('#sn').append($('<option>').text(item.SEMESTERNO).attr('value', item.SEMESTERID));
});  });
 	  
 	
 	
 	  });    });  });  });