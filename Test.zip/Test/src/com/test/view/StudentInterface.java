package com.test.view;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class StudentInterface
 */
@WebServlet("/StudentInterface")
public class StudentInterface extends HttpServlet {
	private static final long serialVersionUID = 1L;

    /**
     * Default constructor. 
     */
    public StudentInterface() {
        // TODO Auto-generated constructor stub
    }
    

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter out=response.getWriter();
		   out.println("<script src=asset/jquery-2.2.1.min.js></script>");
	       out.println("<script src=statecity.js></script>");
	       out.println("<link rel='stylesheet' type='text/css' href='home2/css/bootstrap.min.css'>");
		       
	       //out.println("<a href=DisplayAllStudents class='btn btn-success'>Display All Student Record</a>&nbsp;&nbsp;<a href=BranchInterface class='btn btn-info'>For Branch</a>");
	       out.println("<table class='table table-bordered'><caption><h3>Student Registration</h3></caption>");
		
		
   		   out.println("<html><form action=StudentSubmit method=post enctype=multipart/form-data>");
		   out.println("<html><form action=StudentSubmit>");
		  
	     
	       out.println("<tr><td><b><i>Student Id:</i></b></td><td><input type=text name=sid size=40></td></tr>");
	       out.println("<tr><td><b><i>Student Name:</i></b></td><td><input type=text name=sn size=40></td></tr>");
	       out.println("<tr><td><b><i>Father's Name:</i></b></td><td><input type=text name=sfn size=40></td></tr>");
	       out.println("<tr><td><b><i>Birth Date:</i></b></td><td><input type=date name=dob size=40></td></tr>");
	       out.println("<tr><td><b><i>Gender:</i></b></td><td><input type=radio name=sg value=Male> Male <input type=radio name=sg value=Female> Female</td></tr>");
	       out.println("<tr><td><b><i>Address:</i></b></td><td><textarea  name=sa rows=3 cols=40></textarea></td></tr>");
	      
	       
	       
	       
	       out.println("<tr><td><b><i>State:</i></b></td><td><select class='form-control-static' name=ss id=ss></select></td></tr>");
	       out.println("<tr><td><b><i>City:</i></b></td><td><select class='form-control-static' name=sc id=sc></select></td></tr>");
	     
	       
	       
	       
	       
	       out.println("<tr><td><b><i>Father's No:</i></b></td><td><input type=number name=scon size=40></td></tr>");
	       out.println("<tr><td><b><i>Mobile No:</i></b></td><td><input type=number name=smob size=40></td></tr>");
	       out.println("<tr><td><b><i>Email Id:</i></b></td><td><input type=email name=smail size=40></td></tr>");
	      out.println("<tr><td><b><i>Year:</i></b></td><td><select class='form-control-static' name=syear><option value=\"1\">1</option><option value=\"2\">2</option><option value=\"3\">3</option><option value=\"4\">4</option></select></td></tr>");
	       
	       out.println("<tr><td><b><i>Branch:</i></b></td><td><select class='form-control-static' name=sbranch><option value=\"CSE\">CSE</option><option value=\"IT\">IT</option></select></td></tr>");
	       out.println("<tr><td><b><i>Photograph:</i></b></td><td><input type=file name=spic size=40></td></tr>");
	       out.println("<tr><td><b><i>Password:</i></b></td><td><input type=password name=spass id=spass size=40></td></tr>");
	       
	       
	       out.println("<tr><td><input type=submit class='btn btn-success'></td><td><input type=reset class='btn btn-warning'></td></tr>");
	       //out.println("</table></form></html>");
	       
	       out.println("</table></form></br></div></body></html>");
	       out.flush();
	       
	       
	       
	       
	       
	       
	       
	       
	       
	       
	       
	       
	       
	       
	       /*out.println("<link rel='stylesheet' type='text/css' href='home2/css/bootstrap.min.css'>");
			out.println("<link rel='stylesheet' type='text/css' href='home2/css/font-awesome.min.css' media='all'>");
			out.println("<link rel='stylesheet' type='text/css' href='home2/css/simple-line-icons.css' media='all'>");
			out.println("<link rel='stylesheet' type='text/css' href='home2/css/owl.carousel.css'>");
			out.println("<link rel='stylesheet' type='text/css' href='home2/css/owl.theme.css'>");
			out.println("<link rel='stylesheet' type='text/css' href='home2/css/jquery.bxslider.css'>");
			out.println("<link rel='stylesheet' type='text/css' href='home2/css/jquery.mobile-menu.css'>");
			out.println("<link rel='stylesheet' type='text/css' href='home2/css/style.css' media='all'>");
			out.println("<link rel='stylesheet' type='text/css' href='home2/css/revslider.css' >");
			out.println("<!-- Google Fonts -->");
			out.println("<link href='https://fonts.googleapis.com/css?family=Open+Sans:700,600,800,400' rel='stylesheet' type='text/css'>");
			out.println("<link href='https://fonts.googleapis.com/css?family=Poppins:400,300,500,600,700' rel='stylesheet' type='text/css'>");
			out.println("</head>");
			out.println("<body class='category-page'>");
			out.println("<div id='page'>"); 
			out.println("<!-- Header -->");
			  out.println("<header>");
			    out.println("<div class='header-container'>");
			      out.println("<div class='container'>");
			        out.println("<div class='row'>");
			          out.println("<div class='col-lg-2 col-md-2 col-sm-3 col-xs-12 logo-block'>"); 
			          out.println("<!-- Header Logo -->");
			            out.println("<div class='logo'> <a title='Magento Commerce' href='#'><img alt='Magento Commerce' src='home2/images/logo.png'> </a> </div>");
			            out.println("<!-- End Header Logo -->");
			        out.println("</div>");
			       out.println("</div>");
			      out.println("</div>");
			    out.println("</div>");
			  out.println("</header>");
			  out.println("<nav style='margin-top:0px;'>");
			  out.println("<div class='container'>");
			     out.println("<div class='mm-toggle-wrap'>");
			        out.println("<div class='mm-toggle'><i class='fa fa-align-justify'></i><span class='mm-label'>Menu</span> </div>");
			      out.println("</div>");
			      out.println("<div class='nav-inner'>");
			      out.println("<!-- BEGIN NAV -->");
			       out.println(" <ul id='nav' class='hidden-xs'>");
			          out.println("<li> <a href='HomePage.html'><img src='home.jpg' alt=''>  </a> </li>");
			          out.println("<li class='level0 parent drop-menu' id='nav-home'><a href='AdminLogin' class='level-top'><span>Admin Login</span></a></li>");
			   out.println("<li class='level0 nav-6 level-top drop-menu'> <a class='level-top' href='TeacherLogin'> <span>Teacher Login</span> </a></li>");
			  out.println("<li class='mega-menu'> <a class='level-top active' href='StudentLogin'><span>Student Login</span></a></li>");
			  out.println("<li class='mega-menu'> <a class='level-top' href='ParentLogin'><span>Parent Login</span></a> </li>");
			  out.println("</ul>");
			       
			       out.println("</div>");
			         
			         
			       out.println("</div>");
			      out.println("</div>");
			   out.println("</div>");
			 out.println("</nav>");


	        out.println("  <section class='main-container col1-layout'>");
	        out.println("    <div class='main container'>");
	        out.println("      <div class='account-login'>");
	        out.println("        <div class='page-title'>");
	        out.println("          <h2>SignUp</h2>");
	        out.println("        </div>");
	        out.println("        <fieldset class='col2-set'>");
	        out.println("          <div class='col-1 new-users'><strong>Registration Page</strong>");
	        out.println("            <div class='content'>");
	        out.println("              <p>We love greeting new Students because it allows us the opportunity to describe the New Learning App.</p>");
	        /*out.println("              <div class='buttons-set'>");
	        out.println("                <button onClick='#' class='button create-account' type='button'><span>Create an Account</span></button>");
	        out.println("              </div>");
	        out.println("            </div>");
	        out.println("          </div>");
	        out.println("          <div class='col-2 registered-users'><strong>Administrator Login</strong>");
	        out.println("<script src=asset/jquery-2.2.1.min.js></script>");
	        out.println("<script src=statecity.js></script>");
	        
	            
	        out.println("<a href=DisplayAllStudents>Display All Student Record</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href=BranchInterface>For Branch</a>");
	        out.println("<table><caption><h3>Student Registration</h3></caption>");
	        out.println("<html><form action=StudentSubmit method=post enctype=multipart/form-data>");
	        out.println("<html><form action=StudentSubmit>");
	       
	        
	        
	        out.println("            <div class='content'>");
	        out.println("              <ul class='form-list'>");
	        out.println("                <li>");
	        out.println("                  <label for='#'>Student ID: <span class='required'>*</span></label>");
	        out.println("                  <input type='text' name=sid class='input-text required-entry'>");
	        out.println("                </li>");
	        out.println("                <li>");
	        out.println("                  <label for='#'>Student Name: <span class='required'>*</span></label>");
	        out.println("                  <input type='text' name=sn class='input-text required-entry '>");
	        out.println("                </li>");
	        
	        out.println("                <li>");
	        out.println("                  <label for='#'>Father's Name: <span class='required'>*</span></label>");
	        out.println("                  <input type='text' name=sfn class='input-text required-entry '>");
	        out.println("                </li>");
	        
	        out.println("                <li>");
	        out.println("                  <label for='#'>Birth Date:<span class='required'>*</span></label>");
	        out.println("                  <input type='date' name=dob class='input-text required-entry '>");
	        out.println("                </li>");
	        
	        out.println("                <li>");
	        out.println("                  <label for='#'>Gender:<span class='required'>*</span></label>");
	        out.println("                  <input type='radio'  value='Male' name=gen>Male<input type='radio'  name=gen value='Female'> Female");
	        out.println("                </li>");
	        
	        out.println("                <li>");
	        out.println("                  <label for='#'>Address: <span class='required'>*</span></label>");
	        out.println("                  <input type='textarea' name=sa class='input-text required-entry '>");
	        out.println("                </li>");
	        
	        out.println("                <li>");
	        out.println("                  <label for='#'>State:<span class='required'>*</span></label>");
	        out.println("                  <select name=ss id=ss  class='input-text required-entry' ></select>");
	        out.println("                </li>");
	        
	        out.println("                <li>");
	        out.println("                  <label for='#'>City:<span class='required'>*</span></label>");
	        out.println("                  <select name=sc id=sc  class='input-text required-entry' ></select>");
	        out.println("                </li>");
	        
	        out.println("                <li>");
	        out.println("                  <label for='#'>Father's No: <span class='required'>*</span></label>");
	        out.println("                  <input type='number' name=scon class='input-text required-entry'>");
	        out.println("                </li>");
	        out.println("                <li>");
	        out.println("                  <label for='#'>Mobile No:<span class='required'>*</span></label>");
	        out.println("                  <input type='number' name=smob class='input-text required-entry'>");
	        out.println("                </li>");
	        out.println("                <li>");
	        out.println("                <li>");
	        out.println("                  <label for='#'>Email Id: <span class='required'>*</span></label>");
	        out.println("                  <input type='email' name=smail class='input-text required-entry'>");
	        out.println("                </li>");
	        out.println("                <li>");
	        out.println("                <li>");
	        out.println("                  <label for='#'>Year: <span class='required'>*</span></label>");
	        out.println("                  <input type='text' name=syear class='input-text required-entry'>");
	        out.println("                </li>");
	        out.println("                <li>");
	        out.println("                <li>");
	        out.println("                  <label for='#'>branch: <span class='required'>*</span></label>");
	        out.println("                  <input type='text' name=sbranch class='input-text required-entry'>");
	        out.println("                </li>");
	        out.println("                <li>");
	        out.println("                <li>");
	        out.println("                  <label for='#'>Photograph: <span class='required'>*</span></label>");
	        out.println("                  <input type='file' name=spic class='input-text required-entry'>");
	        out.println("                </li>");
	        out.println("                <li>");
	        out.println("                <li>");
	        out.println("                  <label for='#'>Password: <span class='required'>*</span></label>");
	        out.println("                  <input type='password' name=spass class='input-text required-entry'>");
	        out.println("                </li>");
	        out.println("                <li>");
	        out.println("                <li>");
	        out.println("              </ul>");
	        out.println("              <p class='required'>* Required Fields</p>");
	        out.println("              <div class='buttons-set'>");
	        out.println("                <button type='submit' class='button login'><span>Login</span></button>");
	        out.println("</div></form>");
	        out.println("            </div>");
	        out.println("          </div>");
	        out.println("        </fieldset>");
	        out.println("      </div>");
	        out.println("      <br>");
	        out.println("      <br>");
	        out.println("      <br>");
	        out.println("      <br>");
	        out.println("      <br>");
	        out.println("    </div>");
	        out.println("  </section>");
	        out.println("  <!-- Footer -->  <footer class='footer'>");
	        out.println("    <div class='newsletter-wrap'>");
	        out.println("      <div class='container'>");
	        out.println("        <div class='row'>");
	        out.println("          <div class='col-xs-12'>");
	        out.println("          </div>");
	        out.println("        </div>");
	        out.println("      </div>");
	        out.println("    </div>");
	        out.println("  <footer class='footer'> ");
	        out.println("    <div class='footer-middle'>");
	        out.println("      <div class='container'>");
	        out.println("        <div class='row'>");
	        out.println("        </div>");
	        out.println("      </div>");
	        out.println("    </div>");
	        out.println("  </footer> ");
	        out.println("</div>");
	        out.println("<script type='text/javascript' src='home2/js/jquery.min.js'></script> ");
	        out.println("<script type='text/javascript' src='home2/js/bootstrap.min.js'></script> ");
	        out.println("<script type='text/javascript' src='home2/js/revslider.js'></script> ");
	        out.println("<script type='text/javascript' src='home2/js/common.js'></script> ");
	        out.println("<script type='text/javascript' src='home2/js/jquery.bxslider.min.html'></script> ");
	        out.println("<script type='text/javascript' src='home2/js/owl.carousel.min.js'></script> ");
	        out.println("<script type='text/javascript' src='home2/js/jquery.mobile-menu.min.js'></script>");
	        out.println("</body>");
	        out.println("</html>");
	        out.flush();*/
     	
	}

}
