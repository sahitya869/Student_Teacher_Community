package com.test.view;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.test.dao.StudentDAO;

/**
 * Servlet implementation class SubmitStudentsMarks
 */
@WebServlet("/SubmitStudentsMarks")
public class SubmitStudentsMarks extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SubmitStudentsMarks() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		PrintWriter out=response.getWriter();
		try{
			String sid=request.getParameter("sid");
			ResultSet rs=StudentDAO.FillById(sid);
			
			
			out.println("<html><form action=StudentSubmit>");
			  
		     
		       out.println("<tr><td><b><i>Student Id:</i></b></td><td><input type=text name=sid size=40></td></tr>");
		       out.println("<tr><td><b><i>Student Name:</i></b></td><td><input type=text name=sn size=40></td></tr>");
		       out.println("<tr><td><b><i>Father's Name:</i></b></td><td><input type=text name=sfn size=40></td></tr>");
		       out.println("<tr><td><b><i>Birth Date:</i></b></td><td><input type=text name=dob size=40></td></tr>");
		       out.println("<tr><td><b><i>Gender:</i></b></td><td><input type=radio name=sg value=Male>Male<input type=radio name=eg value=Female>Female</td></tr>");
		       out.println("<tr><td><b><i>Address:</i></b></td><td><textarea  name=sa rows=3 cols=40></textarea></td></tr>");
		      
		}catch(Exception e)
		{out.println(e);
			
		}
		
	}

}
