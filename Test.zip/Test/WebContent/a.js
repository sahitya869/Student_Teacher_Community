jQuery('document').ready(function(){

	
	
	
	
});