package com.test.view;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.test.dao.AnswerDAO;

/**
 * Servlet implementation class StudentAnswerInterface
 */
@WebServlet("/StudentAnswerInterface")
public class StudentAnswerInterface extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public StudentAnswerInterface() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter out=response.getWriter();
		try{
			out.println("<html>");
			String sid=request.getParameter("sid");
			ResultSet rs=AnswerDAO.displayQueryAnswers(sid);
			if(rs.next())
		       {
		    	   out.println("<centre><table>");
			       out.println("<caption><b><i><h1>Your Queries</h1></i></b></caption>");
			       do
			       {
			    	   out.println("<tr><td>Query ID:"+rs.getString(1)+"."+rs.getString(5).toUpperCase()+"</td></tr><br><br>");
			    	   String q=(rs.getString(5).toUpperCase()).replace(" ","+");
			    	   String a=(rs.getString(6).toUpperCase()).replace(" ","+");
			    	   out.println("<tr><td><a href=AnswerInterface?qid="+rs.getString(1)+"&aid="+rs.getString(7)+"&tid="+rs.getString(2)+"&que="+q+"&ans="+a+"&ad="+rs.getString(4)+">Check Answer</a></td></tr>");
			    	   
			       }while(rs.next());
			       out.println("</table></centre>");
		       }
		       else
		       {
		    	 out.println("<b><i>No Queries Yet !!!</i></b>");  
		       }
		       out.println("</html>");
		       out.flush();      
		}catch(Exception e){}
	}

}
