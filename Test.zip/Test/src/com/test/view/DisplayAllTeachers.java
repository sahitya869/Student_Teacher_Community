package com.test.view;


import java.io.IOException;
import java.io.PrintWriter;
import java.sql.ResultSet;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.test.dao.TeacherDAO;

/**
 * Servlet implementation class DisplayAllTeachers
 */
@WebServlet("/DisplayAllTeachers")
public class DisplayAllTeachers extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DisplayAllTeachers() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter out=response.getWriter();
		   try{
			ResultSet rs=TeacherDAO.DisplayAllTeacher();
		     out.println("<html>");
		     out.println("<link rel='stylesheet' type='text/css' href='home2/css/bootstrap.min.css'><style>.table{font-size:11px;}</style>");
		     //out.println("<a href=TeacherInterface class='btn btn-danger'>Add New Teacher</a><br>");
		   if(rs.next())
		   {out.println("<table class='table table-bordered'>");
		    out.println("<tr><th>TeacherId<br>Name</th><th>DOB<br>Gender</th><th>Address</td><td>State<br>City</th><th>Contact<br>Mobile number<br>Email ID</th><th>Joining Date</th><th>Qualification<br>Designation</th><th>Photograph</th><th>Update</th></tr>");
		   do{
		    
		    out.println("<tr><td>"+rs.getString(1)+"<br>"+rs.getString(2)+"</td><td>"+rs.getString(3)+"<br>"+rs.getString(4)+"</td><td>"+rs.getString(5)+"</td><td>"+rs.getString(6)+"<br>"+rs.getString(7)+"</td><td>"+"Landline:"+rs.getString(8)+"<br>Mobile:"+rs.getString(9)+"<br>"+rs.getString(10)+"</td><td>"+rs.getString(11)+"</td><td>"+rs.getString(12)+"<br>"+rs.getString(13)+"</td><td><img src=pic/"+rs.getString(15)+" width=60 height=60></td><td><a href=UpdateDeleteTeacher?tid="+rs.getString(1)+" class='btn btn-info'>Edit/Delete</a></td></tr>");	
		   }while(rs.next());
		    	
		   
			   rs.close();
			   out.println("</table>");
		   }
		   else
		   {
			out.println("Record Not Found..");   
		   }
		    out.println("</html>");
		   }catch(Exception e)
		   {out.println(e);
			   
		   }
			}

		}





