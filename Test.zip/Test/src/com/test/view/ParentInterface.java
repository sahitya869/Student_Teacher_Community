package com.test.view;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class ParentInterface
 */
@WebServlet("/ParentInterface")
@MultipartConfig(fileSizeThreshold=1024*1024*2,//2MB
maxFileSize=1024*1024*10,//10MB
maxRequestSize=1024*1024*50)


public class ParentInterface extends HttpServlet {
	private static final long serialVersionUID = 1L;

    /**
     * @see HttpServlet#HttpServlet()
     * 
     * 
     */
    public ParentInterface() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
       PrintWriter out=response.getWriter();
       
       out.println("<script src=asset/jquery-2.2.1.min.js></script>");
	      out.println("<script src=statecity.js></script>");
       
	     
       out.println("<html><head><link rel='stylesheet' type='text/css' href='home2/css/bootstrap.min.css'></head><form action=ParentSubmit>");
       //out.println("<a href=DisplayAllParents class='btn btn-info'>Display All Parents</a>");

       out.println("<caption><h3>Parent/Guardian Register</h3></caption><table class='table table-bordered'>");
       out.println("<tr><td><b><i>Parent Id:</i></b></td><td><input type=text name=pid size=40></td></tr>");
       out.println("<tr><td><b><i>Name:</i></b></td><td><input type=text name=pn size=40></td></tr>");
       out.println("<tr><td><b><i>Student's Name:</i></b></td><td><input type=text name=stdn size=40></td></tr>");
       out.println("<tr><td><b><i>Birth Date:</i></b></td><td><input type=text name=dob size=40></td></tr>");
       out.println("<tr><td><b><i>We are student's:</i></b></td><td><input type=radio name=pg value=Parent>Parent<input type=radio name=pg value=Guardian>Guardian</td></tr>");
       out.println("<tr><td><b><i>Address:</i></b></td><td><textarea  name=pa rows=3 cols=40></textarea></td></tr>");
       
       
       
       out.println("<tr><td><b><i>State:</i></b></td><td><select class='form-control-static' name=ps id=ss></select></td></tr>");
       out.println("<tr><td><b><i>City:</i></b></td><td><select class='form-control-static' name=pc id=sc></select></td></tr>");
     
       
       
       
       out.println("<tr><td><b><i>Contact No:</i></b></td><td><input type=text name=pcon size=40></td></tr>");
       out.println("<tr><td><b><i>Mobile:</i></b></td><td><input type=text name=pmob size=40></td></tr>");
       out.println("<tr><td><b><i>Email Id:</i></b></td><td><input type=text name=pemail size=40></td></tr>");
       out.println("<tr><td><b><i>Admission Date:</i></b></td><td><input type=text name=stdadm size=40></td></tr>");
       out.println("<tr><td><b><i>Qualification:</i></b></td><td><textarea  name=pq rows=3 cols=40></textarea></td></tr>");
       out.println("<tr><td><b><i>Password:</i></b></td><td><input type=password name=ppass size=40></td></tr>");
       out.println("<tr><td><b><i>Photograph:</i></b></td><td><input type=file name=ppic size=40></td></tr>");
       out.println("<tr><td><input type=submit class='btn btn-success'></td><td><input class='btn btn-warning' type=reset></td></tr>");
       out.println("</table></form></html>");
       out.flush();

	}

}


