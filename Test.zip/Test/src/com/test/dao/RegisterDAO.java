package com.test.dao;

import java.sql.Connection;
import java.sql.DriverManager;

import com.test.model.Register;


public class RegisterDAO {
	
	static String provider="jdbc:mysql://localhost:3306/studentinfo";
	
	
	public static boolean AddNewId(Register A)
	{try{
		Class.forName("com.mysql.jdbc.Driver").newInstance();
		Connection cn=DriverManager.getConnection(provider,"root","123");
		
		String query="insert into Register value('"+A.getYourid()+"')";
		System.out.println(query);
		
		 boolean st=DBHelper.executeUpdate(cn, query);
		 return st;
	}	catch(Exception e)
	 {System.out.println(e);
		 return false;
	 }

}}