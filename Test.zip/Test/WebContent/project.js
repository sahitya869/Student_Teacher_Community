$(document).ready(
        function() {
 
        	
            $('#btn').click(
            function() {
                
                $.getJSON('StudentDisplayJSON', {
                   
                    ajax : 'true'
                }, function(data) {
                    
                    var html = '<table border=1>';
                   // var len = data.length;
                    html+="<tr><th>Student ID</th><th>Student Name</th><th>Edit/Delete</th></tr>";
                    $.each(data, function(i, item) {
                    	html += '<tr><td>' + item.VID + '</TD><TD>' + item.VNAME + '</TD><TD><a href=VehicleDisplayByID?vid='+item.VID+'>Edit/Delete</a></TD></TR>'; 
                      });
                     
                    html += '</TABLE>';
   
                    $('#result').html(html);
                });
            });
            
            
        });
       
   