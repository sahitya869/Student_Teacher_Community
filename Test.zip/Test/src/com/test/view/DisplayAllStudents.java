

package com.test.view;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.test.dao.StudentDAO;

/**
 * Servlet implementation class DisplayAllStudents
 */
@WebServlet("/DisplayAllStudents")
public class DisplayAllStudents extends HttpServlet {
	private static final long serialVersionUID = 1L;

    /**
     * Default constructor. 
     */
    public DisplayAllStudents() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter out=response.getWriter();
		   try{
			ResultSet rs=StudentDAO.DisplayAll();
		     out.println("<html>");
		     out.println("<link rel='stylesheet' type='text/css' href='home2/css/bootstrap.min.css'><style>.table{font-size:11px;}</style>");
		   if(rs.next())
		   {out.println("<table class='table table-bordered'>");
		    out.println("<tr><th>StudentId<br>Name</th><th>DOB<br>Gender</th><th>Address</th><th>State</th><th>city</th><th>Father'snumber</th><th>Student's Mobile:</th><th>Emailid</th><th>Year<br>Branch</th><th>Photograph</th><th>Update</th></tr>");
		    do
		    { String g="";
		    	if(rs.getString(5).equals("Female"))
		    	{g=" d/o ";}
		    	else
		    	{g=" s/o ";}
		    
		    out.println("<tr><td>"+rs.getString(1)+"<br>"+rs.getString(2)+g+rs.getString(3)+"</td><td>"+rs.getString(4)+"<br>"+rs.getString(5)+"</td><td>"+rs.getString(6)+"</td><td>"+rs.getString(7)+"</td><td>"+rs.getString(8)+"</td><td>"+rs.getString(9)+"</td><td>"+rs.getString(10)+"</td><td>"+rs.getString(11)+"</td><td>"+rs.getString(12)+"<br>"+rs.getString(13)+"</td><td><img src=pic/"+rs.getString(14)+" width=60 height=60>"+"</td><td><a href=UpdateDeleteStudent?sid="+rs.getString(1)+" class='btn btn-info'>Edit/Delete</a></td></tr>");	
		    	
		    	
		    }while(rs.next());
			   rs.close();
			   out.println("</table>");
		   }
		   else
		   {
			out.println("Record Not Found..");   
		   }
		    out.println("</html>");
		   }catch(Exception e)
		   {out.println(e);
			   
		   }
			}
	}


