package com.test.view;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class ParentHome
 */
@WebServlet("/ParentHome")
public class ParentHome extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ParentHome() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		 PrintWriter out=response.getWriter();
	     HttpSession ses=request.getSession();
	     out.println("<html>");
		 try{
			 
			 
			 
			 out.println("<html lang='en'>");
			 out.println("<link rel='stylesheet' type='text/css' href='home2/css/bootstrap.min.css'>");
			 out.println("<link rel='stylesheet' type='text/css' href='home2/css/font-awesome.min.css' media='all'>");
			 out.println("<link rel='stylesheet' type='text/css' href='home2/css/simple-line-icons.css' media='all'>");
			 out.println("<link rel='stylesheet' type='text/css' href='home2/css/owl.carousel.css'>");
			 out.println("<link rel='stylesheet' type='text/css' href='home2/css/owl.theme.css'>");
			 out.println("<link rel='stylesheet' type='text/css' href='home2/css/jquery.bxslider.css'>");
			 out.println("<link rel='stylesheet' type='text/css' href='home2/css/jquery.mobile-menu.css'>");
			 out.println("<link rel='stylesheet' type='text/css' href='home2/css/style.css' media='all'>");
			 out.println("<link rel='stylesheet' type='text/css' href='home2/css/revslider.css' >");
			 out.println("<!-- Google Fonts -->");
			 out.println("<link href='https://fonts.googleapis.com/css?family=Open+Sans:700,600,800,400' rel='stylesheet' type='text/css'>");
			 out.println("<link href='https://fonts.googleapis.com/css?family=Poppins:400,300,500,600,700' rel='stylesheet' type='text/css'>");
			 out.println("</head>");
			 out.println("<body class='category-page' style='background-image:url(1234d.jpg);'>");
			 out.println("<div id='page'> ");
			 out.println("  <header>");
			 out.println("    <div class='header-container'>");
			 out.println("      <div class='container'>");
			 out.println("        <div class='row'>");
			 out.println("          <div class='col-lg-2 col-md-2 col-sm-3 col-xs-12 logo-block'> ");
			 out.println("            <!-- Header Logo -->");
			 out.println("            <div class='logo'> <a  href='HomePage.html'><img src='home2/images/logo.png' class='img-responsive'> </a> </div>");
			 out.println("            <!-- End Header Logo --> ");
			 out.println("          </div>");
			 out.println("        </div>");
			 out.println("      </div>");
			 out.println("    </div>");
			 out.println("  </header>");
			 out.println("  <nav>");
			 out.println("    <div class='container'>");
			 out.println("      <div class='mm-toggle-wrap'>");
			 out.println("        <div class='mm-toggle'><i class='fa fa-align-justify'></i><span class='mm-label'>Menu</span> </div>");
			 out.println("      </div>");
			 out.println("      <div class='nav-inner'> ");
			 out.println("        <!-- BEGIN NAV -->");
			 out.println("        <ul id='nav' class='hidden-xs'>");
			 //out.println("          <li class='mega-menu'> <a class='level-top' href='HomePage.html'><span>HomePage</span></a> </li>");
			 
			 out.println("          <li class='level0 parent drop-menu' id='nav-home'><a class='level-top' href='AdminLogin'><span>Admin Login</span></a></li>");
			 out.println("          <li class='level0 nav-6 level-top drop-menu'> <a class='level-top' href='TeacherLogin'> <span>Teacher Login</span> </a></li>");
			 out.println("          <li class='mega-menu'> <a class='level-top' href='StudentLogin'><span>Student Login</span></a></li>");
			 out.println("          <li class='mega-menu'> <a class='level-top active' href='ParentLogin'><span>Parent Login</span></a> </li>");
			 out.println("        </ul>");
			 out.println("        <!--nav-->");
			 out.println("        <div class='top-cart-contain'> ");
			 out.println("          <!-- Top Cart -->");
			 out.println("          <div class='mini-cart'>");
			// out.println(" <div > <h6><font color=green>Admin Id:"+ses.getValue("SAID").toString()+"</font>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"+ses.getValue("LDATE").toString()+"&nbsp;<a href=AdminLogout>Logout</a></h6> </div>");
			 
			 out.println("<font color=green>Parent Id:"+ses.getValue("PEID").toString()+"["+ses.getValue("PEN").toString()+"]</font>&nbsp;"+ses.getValue("LDATE").toString()+"&nbsp;<a href=StudentLogout>Logout</a>&nbsp;<img src=pic/"+ses.getValue("PPIC").toString()+" width=25 height=25>");

			 out.println("            <div>");
			 out.println("            </div>");
			 out.println("          </div>");
			 out.println("          <!-- Top Cart -->");
			 out.println("        </div>");
			 out.println("      </div>");
			 out.println("    </div>");
			 out.println("  </nav>");
			 out.println("");
				
			 out.println(" <!-- Main Container -->");
			 out.println("  <section class='main-container col2-left-layout bounceInUp animated'>");
			 out.println("    <div class='container'>");
			 out.println("      <div class='row'>");
			 out.println("        <div class='col-sm-9 col-sm-push-3'>");
			 out.println("          <article class='col-main'>");
			 out.println("            <div class='category-products'>");
			 out.println("<div class='myIframe'> <iframe frameborder=0  style='background-image:url(star.png);' width=900 height=800 name=mw></iframe>");
			 out.println(" </div></div>");
			 out.println("          </article>");
			 out.println("        </div>");
			 out.println("        <div class='col-left sidebar col-sm-3 col-xs-12 col-sm-pull-9'>");
			 
			 
			 
			 
			 
			 out.println("          <aside class='col-left sidebar'>");
			 out.println("            <div class='side-nav-categories'>");
			 out.println("              <div class='block-title'> Categories </div>");
			 out.println("              <div class='box-content box-category'>");
			 out.println("                <ul>");
			 out.println("                  <li> <a href='HomePage.html' target='mw'>GoTo Home Page</a> <span class='subDropdown minus'></span></li>");
			 out.println("                  <li> <a href='AskQuestion' target='mw'>Any Query</a> </li>");
			 out.println("                  <li> <a href='DisplayAllTeachers'>All Teachers</a> </li>");
			 out.println("                </ul>");
			 out.println("              </div>");
			 out.println("            </div>");
			 out.println("          </aside>");
			 
			 
			 
			 out.println("          <aside class='col-left sidebar'>");
			 out.println("            <div class='side-nav-categories'>");
			 out.println("              <div class='block-title'> Others </div>");
			 out.println("              <div class='box-content box-category'>");
			 out.println("                <ul>");
			 //out.println("                  <li> <a href='ParentInterface' target='mw'>Registration Page</a> <span class='subDropdown minus'></span></li>");
			 out.println("                  <li> <a href='Assignment.html'>Assginment</a> </li>");
			 out.println("                  <li> <a href='gallery.html'>Gallery</a> </li>");
			 out.println("                  <li> <a href='StudentInterface' target='mw'>Register For a Child</a> </li>");
			 out.println("                  <li> <a href='ParentInterface' target='mw'>Register For a Parent</a> </li>");
				
			 out.println("                  <li> <a href='HomePage.html'>Logout</a> </li>");
			 
			 out.println("                </ul>");
			 out.println("              </div>");
			 out.println("            </div>");
			 out.println("          </aside>");
			 
			 
			 
			 
			 
			 out.println("        </div>");
			 out.println("      </div>");
			 out.println("    </div>");
			 out.println("  </section>");
			 out.println("<footer class='footer'> ");
			 out.println("    <div class='footer-middle'>");
			 out.println("      <div class='container'>");
			 out.println("        <div class='row'>");
			 out.println("        </div>");
			 out.println("      </div>");
			 out.println("    </div>");
			 out.println("  </footer> ");
			 out.println("</div>");
			 out.println("<div id='mobile-menu'>");
		        out.println("  <ul>");
		        out.println("                  <li> <a class='active' href='ParentInterface' target='mw'>Registration Page</a> <span class='subDropdown minus'></span></li>");
				 out.println("                  <li> <a href='AskQuestion' target='mw'>Any Query</a> </li>");
				 out.println("                  <li> <a href='Assignment.html'>Assginment</a> </li>");
				 out.println("                  <li> <a href='DisplayMarks' target='mw'>Marks</a> </li>");		 
				 out.println("                  <li> <a href='StudentInterface' target='mw'>Register For a Child</a> </li>");
				 
				 out.println("                  <li> <a href='HomePage.html'>Logout</a> </li>");
		        out.println("   </ul>");
		        out.println("</div>");
		        out.println("<div id='mobile-menu'>");
		        out.println("  <ul>");
		        out.println("                  <li> <a class='active' href='ParentInterface' target='mw'>Registration Page</a> <span class='subDropdown minus'></span></li>");
				 out.println("                  <li> <a href='AskQuestion' target='mw'>Any Query</a> </li>");
				 out.println("                  <li> <a href='Assignment.html'>Assginment</a> </li>");
				 out.println("                  <li> <a href='DisplayMarks' target='mw'>Marks</a> </li>");		 
				 out.println("                  <li> <a href='StudentInterface' target='mw'>Register For a Child</a> </li>");
				 
				 out.println("                  <li> <a href='HomePage.html'>Logout</a> </li>");
		        out.println("   </ul>");
		        out.println("</div>");
			 out.println("<script type='text/javascript' src='home2/js/jquery.min.js'></script> ");
			 out.println("<script type='text/javascript' src='home2/js/bootstrap.min.js'></script>  ");
			 out.println("<script type='text/javascript' src='home2/js/common.js'></script> ");
			 out.println("<script type='text/javascript' src='home2/js/owl.carousel.min.js'></script> ");
			 out.println("<script type='text/javascript' src='home2/js/jquery.mobile-menu.min.js'></script> ");
			 
			 out.println("<!-- Footer -->  <footer class='footer'>");
			 out.println("<div class='newsletter-wrap'>");
			 out.println("<div class='container'>");
			 out.println("<div class='row'>");
			 out.println("<div class='col-xs-12'>");
			 out.println("<div class='newsletter'>");
			 out.println("<form>");
			 out.println("<div>");
			 out.println("<h4><span>newsletter</span></h4>");
			 out.println("<input type='text' placeholder='Enter your email address' class='input-text' title='Sign up for our newsletter' id='newsletter1' name='email'>");
			 out.println("<button class='subscribe' title='Subscribe' type='submit'><span>Subscribe</span></button>");
			 out.println("</div>");
			 out.println("</form>");
			 out.println("</div>");
			 out.println("</div>");
			 out.println("</div>");
			 out.println("</div>");
			 out.println("</div>");
			 out.println("<!--newsletter-->");

			 out.println("<div class='footer-middle'>");
			 out.println("<div class='container'>");
			 out.println("<div class='row'>");

			 out.println("<div class='col-md-3 col-sm-6'>");
			 out.println("<div class='footer-column pull-left'>");

			 out.println("<img src='http://itmuniversity.ac.in/wp-content/uploads/2016/04/logo3.png' alt='' /></p>");
			 out.println("<p style='text-align: justify;  '>At ITM University Gwalior you get an opportunity to link your studies to your career plan and personal goals by using combination of compulsory credits, optional credits,self-learning credits, MOOC, non-cgpa credits for curricular and extra-curricular activities. Here you get enormous opportunity to share your ideas and domain expertise with industry leaders. Technically you can craft your own degree.</p>");


			 out.println("</div>");
			 out.println("</div>");
			 out.println("<div class='col-md-3 col-sm-6'>");
			 out.println("<div class='footer-column pull-left'>");
			 out.println("<h3 class='widgettitle'>About University</h3>         <div class='textwidget'> <ul>");
			 out.println("<li><a href='http://itmuniversity.ac.in/about-itm/sponsoring-body/'>Sponsoring Body</a></li>");

			 out.println("<li><a href='http://itmuniversity.ac.in/about-itm/awards-rankings/'>Awards Rankings</a></li>");
			 out.println("<li><a href='http://itmuniversity.ac.in/about-itm/vision-mission-and-values/'>Vision Mission & Values</a></li>");
			 out.println("<li><a href='http://itmuniversity.ac.in/about-itm/recognition-and-approvals/'>Recognition & Approvals</a></li>");
			 out.println("<li><a href='http://itmuniversity.ac.in/about-itm/advisors/'>Advisors</a></li>");
			 out.println("<li><a href='http://itmuniversity.ac.in/about-itm/officials/'>Officials</a></li>");
			 out.println("<li><a href='http://itmuniversity.ac.in/messages/'>Messages</a></li>");
			 out.println("<li><a href='http://itmuniversity.ac.in/about-itm/what-gwalior-offers/'>What Gwalior Offers</a></li>");


			 out.println("</ul></div>");
			 out.println("</div>");
			 out.println("</div>");

			 out.println("<div class='col-md-3 col-sm-6'>");
			 out.println("<h4>contact us</h4>");
			 out.println("<div class='contacts-info'>");
			 out.println("<address>");
			 out.println("<i class='add-icon'>&nbsp;</i>AH-43 Bypass, Jhansi Road<br> &nbsp;Lashkar , Gwl (M.P.) 475001");

			 out.println("</address>");
			 out.println("<div class='phone-footer'><i class='phone-icon'>&nbsp;</i> 1800-270-0031</div>");
			 out.println("<div class='email-footer'><i class='email-icon'>&nbsp;</i> <a href='mailto:admission@itmuniversity.ac.in'>admission@itmuniversity.ac.in</a> </div>");
			 out.println("</div>");
			 out.println("</div>");
			 out.println("</div>");
			 out.println("</div>");
			 out.println("</div>");
			 out.println("<div class='footer-top'>");
			 out.println("<div class='container'>");
			 out.println("<div class='row'>");
			 out.println("<div class='col-xs-12 col-sm-6'>");
			 out.println("<div class='social'>");
			 out.println("<ul>");
			 out.println("<li class='fb'><a href='https://www.facebook.com/ITMUNIVERSITYINDIA/?fref=ts'></a></li>");
			 out.println("<li class='tw'><a href='https://twitter.com/itmuniversity'></a></li>");
			 out.println("<li class='googleplus'><a href='https://plus.google.com/110642537105768596324/about'></a></li>");
			 out.println("<li class='linkedin'><a href='https://www.linkedin.com/company/itm-university'></a></li>");
			 out.println("<li class='youtube'><a href='https://www.youtube.com/user/TheITMMusic'></a></li>");
			 out.println("</ul>");
			 out.println("</div>");
			 out.println("</div>");

			 out.println("</div>");
			 out.println("</div>");
			 out.println("</div>");


			 out.println("<div id='mobile-menu'>");
			 out.println("<ul>");
			 out.println("<li>");
			 out.println("<div class='mm-search'>");
			 out.println("<form id='search1' name='search'>");
			 out.println("<div class='input-group'>");
			 out.println("<div class='input-group-btn'>");
			 out.println("<button class='btn btn-default' type='submit'><i class='fa fa-search'></i> </button>");
			 out.println("</div>");
			 out.println("<input type='text' class='form-control simple' placeholder='Search ...' name='srch-term' id='srch-term'>");
			 out.println("</div>");
			 out.println("</form>");
			 out.println("</div>");
			 out.println("</li>");
			 out.println("<li><a href='index.html'>Home</a>");
			 out.println("<ul>");
			 out.println("<li><a href='http://htmldemo.magikcommerce.com/ecommerce/aspire-html-template/home1/index.html'>Home Version 1</a></li>");
			 out.println("<li><a href='index.html'>Home Version 2</a></li>");
			 out.println("</ul>");
			 out.println("</li>");
			 out.println("<li><a href='#'>Pages</a>");
			 out.println("<ul>");
			 out.println("<li><a href='grid.html'>Grid</a> </li>");
			 out.println("<li> <a href='list.html'>List</a> </li>");
			 out.println("<li> <a href='product_detail.html'>Product Detail</a> </li>");
			 out.println("<li> <a href='shopping_cart.html'>Shopping Cart</a> </li>");
			 out.println("<li><a href='checkout.html'>Checkout</a> </li>");
			 out.println("<li> <a href='wishlist.html'>Wishlist</a> </li>");
			 out.println("<li> <a href='dashboard.html'>Dashboard</a> </li>");
			 out.println("<li> <a href='multiple_addresses.html'>Multiple Addresses</a> </li>");
			 out.println("<li> <a href='about_us.html'>About us</a> </li>");
			 out.println("<li><a href='blog.html'>Blog</a>");
			 out.println("<ul>");
			 out.println("<li><a href='blog-detail.html'>Blog Detail</a> </li>");
			 out.println("</ul>");
			 out.println("</li>");
			 out.println("<li><a href='contact_us.html'>Contact us</a> </li>");
			 out.println("<li><a href='404error.html'>404 Error Page</a> </li>");
			 out.println("</ul>");
			 out.println("</li>");



			            
			            
			            
			            
			            
			            
			            
			            
			            
			            
			            
			            
			            
			            
			            
			            
			            
			            
			 out.println("</body>");
			 out.println("</html>");

			 
		
			 }catch(Exception e){
				 response.sendRedirect("AdminLogin");
				 
			 }}}