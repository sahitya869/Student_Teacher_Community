package com.test.view;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.test.dao.StudentDAO;
import com.test.model.Student;

/**
 * Servlet implementation class StudentCheckPwd
 */
@WebServlet("/StudentCheckPwd")
public class StudentCheckPwd extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public StudentCheckPwd() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		
		
		 PrintWriter out=response.getWriter();
			Student S=StudentDAO.CheckPassword(request.getParameter("sid"), request.getParameter("pwd"));
	    if(S!=null)
	    { HttpSession ses=request.getSession();
	    ses.putValue("SEID",request.getParameter("sid"));
	    ses.putValue("LDATE", new java.util.Date());
	    ses.putValue("SEN", S.getStudentname());
	    ses.putValue("SPIC", S.getPhotograph());
	    ses.putValue("BRANCH", S.getBranch());
	    	System.out.println(S.getBranch());
	    	response.sendRedirect("StudentHome");
	    }
	    else
	    {
	    	response.sendRedirect("StudentLogin?a=true");
	    	
	    }
		out.flush();
	
	}



	}


