package com.test.view;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import com.test.dao.BranchSubmitDAO;
import com.test.model.Branch;

/**
 * Servlet implementation class BranchSubmit
 */
@WebServlet("/BranchSubmit")
public class BranchSubmit extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public BranchSubmit() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		
		
		PrintWriter out=response.getWriter();
		  Branch B=new Branch();
		  
		  B.setBranchname(request.getParameter("bn"));
		  B.setSemester(request.getParameter("sem"));
		  B.setSubjectid(request.getParameter("si"));
		  B.setSubjectname(request.getParameter("sn"));
		  B.setStatus(request.getParameter("st"));
		  
		  boolean st=BranchSubmitDAO.AddNewRecord(B);
		  out.println("<html>");
		  if(st)
		  {out.println("<h3><font color=green>Apka ho gaya :)</font></h3>");
			}
		  else
		  {
			  out.println("<h3><font color=red>Apka nahi ho gaya :(</font></h3>");  
			  
		  }  
			  
		  out.println("</html>");
		  
		  out.flush();
		  
		  
		  
	}

	
}
