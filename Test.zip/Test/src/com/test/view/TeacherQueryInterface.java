package com.test.view;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.test.dao.QueryDAO;



/**
 * Servlet implementation class TeacherQueryInterface
 */
@WebServlet("/TeacherQueryInterface")
public class TeacherQueryInterface extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public TeacherQueryInterface() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		PrintWriter out=response.getWriter();
		try{
		       out.println("<html>");
		       String tid=request.getParameter("tid");
		       ResultSet rs=QueryDAO.displayTeacherQueries(tid);
		       if(rs.next())
		       {
		    	   out.println("<centre><table>");
			       out.println("<caption><b><i><h1>List of Queries</h1></i></b></caption>");
			       do
			       {
			    	   
			    	   out.println("<tr><td>Query ID:"+rs.getString(1)+"."+rs.getString(5).toUpperCase()+"</td></tr><br><br>");
			    	   String q=rs.getString(5).replace(" ","+");
			    	   out.println("<tr><td><a href=QueryAnswerInterface?qid="+rs.getString(1)+"&sid="+rs.getString(3)+"&que="+q+">"+rs.getString(6)+"</a></td></tr>");
			    	   
			       }while(rs.next());
			       out.println("</table></centre>");
		       }
		       else
		       {
		    	 out.println("<b><i>No Queries Available !!!</i></b>");  
		       }
		       out.println("</html>");
		       out.flush();
		      }catch(Exception e){}
		
	}

}
