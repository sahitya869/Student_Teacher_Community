package com.test.view;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class AnswerInterface
 */
@WebServlet("/AnswerInterface")
public class AnswerInterface extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AnswerInterface() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		  HttpSession ses=request.getSession(false);
		  String sid= ses.getValue("SEID").toString();
		  String tid=request.getParameter("tid");
		  String ad=request.getParameter("ad");
		  String qid=request.getParameter("qid");
		  String aid=request.getParameter("aid");
		  String que=request.getParameter("que");
		  String ans=request.getParameter("ans");
	        PrintWriter out=response.getWriter();
	        out.println("<html>");
			  out.println("<h4 >Teacher ID :<input type=text value="+tid+" readonly name=tid>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Student ID :<input type=text value="+sid+" readonly name=sid>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Answer Date:<input type=text value="+ad+" readonly name=ad></h4><hr>");
			  out.println("<table>");
			  out.println("<tr><td><b><i>Question(QId="+qid+"):</i></b></td><td>"+que+"</td><br></tr>");
			  out.println("<tr><td><b><i>Answer(AnsId="+aid+"):</i></b></td><td>"+ans+"</td></tr>");
			  out.println("</table></html>");
			  out.flush();
		
	}

}
