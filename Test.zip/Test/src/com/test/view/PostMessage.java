package com.test.view;



import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class PostMessage
 */
@WebServlet("/PostMessage")
public class PostMessage extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public PostMessage() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter out=response.getWriter();
		
		out.println("<!DOCTYPE html><html><head><title>Ask</title>");
		
		out.println("</head>");
	    out.println("<body><center>");  
	    out.println("<h2>Question-Answer Area</h2>");
		out.println("<form id='FormAsk' method='post' action='/ask/'>");
		//out.println("<label for='questionTitle' style='display: none;'>Ask your Question:</label>");
		out.println("<select><option>Choose a Catagory</option><option>Academic</option><option>Examination</option><option>Events</option></select></br></br>");
		out.println("<textarea id='questionTitle' name='title' class='input-text' rows='5' cols='75' style='margin-bottom: 6px;'></textarea>");
		out.println("<p class='charCount' style='float: right; font-size: 10px; color: #888'></p></br>");
		out.println("<input type='submit' id='questionSubmit' class='input-button' value='Post your Question'/>");
		out.println("<input type=button name=clear value=clear>");
		out.println("<select><option>Get Answer From</option><option>All</option><option>Teachers only</option><option>Students Only</option></select></br></br></br>");
		out.println("Questions? -</br><span id=sq></span></br>");
		out.println("Answers  -</br><span id=sq></span></br>");		
		out.println("</form>");
		
	}

}
