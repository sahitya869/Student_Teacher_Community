package com.test.view;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class TeacherInterface
 */
@WebServlet("/TeacherInterface")
public class TeacherInterface extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public TeacherInterface() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	
		PrintWriter out=response.getWriter();
		  out.println("<script src=asset/jquery-2.2.1.min.js></script>");
	      out.println("<script src=statecity.js></script>");
	      out.println("<link rel='stylesheet' type='text/css' href='home2/css/bootstrap.min.css'>");
		
		   //out.println("<a href=DisplayAllTeachers class='btn btn-success'>Display All Teachers Record</a><br>");
	       out.println("<caption><h3>Teacher Registration</h3></caption>");
		
		
		   out.println("<html><form action=TeacherSubmit method=post enctype=multipart/form-data><table class='table table-bordered'>");
 
		   out.println("<tr><td><b><i>Teacher Id:</i></b></td><td><input type=text name=tid size=40></td></tr>");
	       out.println("<tr><td><b><i>Name:</i></b></td><td><input type=text name=tname size=40></td></tr>");
	       out.println("<tr><td><b><i>Birth Date:</i></b></td><td><input type=date name=tdob size=40></td></tr>");
	       out.println("<tr><td><b><i>Gender:</i></b></td><td><input type=radio name=tgen value=Male>Male<input type=radio name=tgen value=Female>Female</td></tr>");
	       out.println("<tr><td><b><i>Address:</i></b></td><td><textarea  name=tadd rows=3 cols=40></textarea></td></tr>");
	      
	       
	       
	       out.println("<tr><td><b><i>State:</i></b></td><td><select name=tstate id=ss></select></td></tr>");
	       out.println("<tr><td><b><i>City:</i></b></td><td><select name=tcity id=sc></select></td></tr>");
	     
	       
	       
	       
	       out.println("<tr><td><b><i>Contact No:</i></b></td><td><input type=text name=tcon size=40></td></tr>");
	       out.println("<tr><td><b><i>Mobile:</i></b></td><td><input type=text name=tmbl size=40></td></tr>");
	       out.println("<tr><td><b><i>Email Id:</i></b></td><td><input type=text name=tmail size=40></td></tr>");
	       out.println("<tr><td><b><i>Joining Date:</i></b></td><td><input type=date name=tdoj size=40></td></tr>");
	       out.println("<tr><td><b><i>Qualification:</i></b></td><td><textarea  name=tqua rows=3 cols=40></textarea></td></tr>");
	       out.println("<tr><td><b><i>Designation:</i></b></td><td><select name=tdes><option value=\"Director\">Director</option><option value=\"Professor\">Professor</option><option value=\"Assistant Professor\">Asst. Professor</option></select></td></tr>");
	       out.println("<tr><td><b><i>Branch:</i></b></td><td><select name=branch><option value=\"CSE\">CSE</option><option value=\"IT\">IT</option></select></td></tr>");
	       
	       out.println("<tr><td><b><i>Password:</i></b></td><td><input type=password name=tpass size=40></td></tr>");
	       out.println("<tr><td><b><i>Photograph:</i></b></td><td><input type=file name=tpic size=40></td></tr>");
	       out.println("<tr><td><input type=submit class='btn btn-success'></td><td><input type=reset class='btn btn-danger'></td></tr>");
	       out.println("</table></form></br></div></body></html>");
	       out.flush();

	}

}
