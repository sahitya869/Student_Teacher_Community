package com.test.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;


import com.test.model.GraphMarks;


public class GraphDAO {
	
	static String provider="jdbc:mysql://localhost:3306/studentinfo";
	 public static boolean AddNewRecord(GraphMarks G)
	 { try{
		 Class.forName("com.mysql.jdbc.Driver").newInstance();   
		 Connection cn=DriverManager.getConnection(provider,"root","123");
	  String query="insert into graph values('"+G.getStudentid()+"','"+G.getPic()+"')";
	   
	  boolean st=DBHelper.executeUpdate(cn, query);
	    return st;
	 }catch(Exception e)
	 {System.out.println(e);
		 return false;
	 }}
	public static ResultSet DisplayAllGraph() {
		// TODO Auto-generated method stub
		 try{
			 Class.forName("com.mysql.jdbc.Driver").newInstance();   
			 Connection cn=DriverManager.getConnection(provider,"root","123");
		  String query="select * from graph";
		  ResultSet rs=DBHelper.executeQuery(cn, query);
		  return rs;
			 
			 
		 }catch(Exception e)
		 {System.out.println(e);
			 return null;
		 }}}