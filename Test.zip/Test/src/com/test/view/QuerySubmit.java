package com.test.view;



import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.test.dao.QueryDAO;
import com.test.model.Query;


/**
 * Servlet implementation class QuerySubmit
 */
@WebServlet("/QuerySubmit")
public class QuerySubmit extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public QuerySubmit() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	
		PrintWriter out=response.getWriter();
		Query Q=new Query();
		Q.setTeacherid(request.getParameter("tid"));
		Q.setStudentid(request.getParameter("sid"));
		Q.setQuerydate(request.getParameter("cd"));
		Q.setQuestion(request.getParameter("que"));
		Q.setStatus("Unanswered");
		boolean st=QueryDAO.addNewQuery(Q);
		if(st)
		  {
			  out.println("<font color=green>Query Submitted.....</font>");
			  
		  }
		  else
		  {out.println("Fail to Submit Query...");
			  
		  }
		  out.flush();
	
	}

}