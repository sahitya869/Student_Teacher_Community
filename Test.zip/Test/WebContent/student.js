$(document).ready(
        function() {
        	
        	
        	
               $('#result').on("click",".vc",function() {
        	        	            	
        	        	 $.getJSON('StudentDisplayByIdJSON', {
        	                 vid:$(this).attr("vid"),
        	                 ajax : 'true'
        	             }, function(data) {
        	            	 $.each(data, function(i, item) {
        	            		$('#vhid').val(item.VID);
        	            		$('#vn').val(item.VNAME);
        	            		
        	            	 });
        	                       });
        	        	            });
                $.getJSON('StudentDisplayJSON', {
                   
                    ajax : 'true'
                }, function(data) {
                    
                    var html = '<table border=1>';
                   // var len = data.length;
                    html+="<tr><th>Vehicle ID</th><th>Vehicle Name</th><th>Edit/Delete</th></tr>";
                    $.each(data, function(i, item) {
                    	html += '<tr><td>' + item.VID + '</TD><TD>' + item.VNAME + '</TD><TD><a href=# class=vc vid='+item.VID+'>Edit/Delete</a></TD></TR>'; 
                      });
                     
                    html += '</TABLE>';
   
                    $('#result').html(html);
                }); 
        });
       
   