package com.test.view;



import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class InterfaceForAdmin
 */
@WebServlet("/InterfaceForAdmin")
public class InterfaceForAdmin extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public InterfaceForAdmin() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
					// TODO Auto-generated method stub
		PrintWriter out=response.getWriter();
		out.println("<!DOCTYPE html><html><head><title>Admin Page</title>");
		out.println("<link rel='stylesheet' type='text/css' href='home2/css/bootstrap.min.css'>");
		out.println("<style>");
		
       // out.println("div { width:40px; padding: 1px; border: 15px solid green; margin: 1px;   }");
		out.println("</style></head>");
		
		
		
		
		
		
		out.println("<body style='background-image:url(star.png);'><center>");
		out.println("<h4>Welcome To Student-Teacher Community</h4>");
		out.println("<center><table class='table table-bordered'>");
		out.println("<tr>");
		out.println("    <td><a href=StudentInterface class='btn btn-success'>Student Registration</a></td>");
		out.println("    <td><a href=DisplayAllTeachers class='btn btn-info'>Display All Teachers</a></td>");
		out.println("  </tr>");
		out.println("  <tr>");
		out.println("    <td><a href=TeacherInterface class='btn btn-success'>Teacher  Registration</a></td>");
		out.println("    <td><a href=DisplayAllStudents class='btn btn-info'>Display All Students</a></td>");
		out.println("  </tr>");
		out.println("  <tr>");
		out.println("    <td><a href=ParentInterface class='btn btn-success'>Parant  Registration</a></td>");
		out.println("    <td><a href=DisplayAllParents class='btn btn-info'>Display All Parants</a></td>");
		out.println("  </tr>");

		out.println("</table></center></body></html>"); 
	}

}
