package com.test.view;


import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import org.softech.FileUpload;

import com.test.dao.TeacherDAO;
import com.test.model.Teacher;

/**
 * Servlet implementation class FinalEditDeleteTeacher
 */
/*@MultipartConfig(fileSizeThreshold=1024*1024*2,//2MB
maxFileSize=1024*1024*10,//10MB
maxRequestSize=1024*1024*50)*/


@WebServlet("/FinalEditDeleteTeacher")
public class FinalEditDeleteTeacher extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public FinalEditDeleteTeacher() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		 PrintWriter out=response.getWriter();
			try{
			String btn=request.getParameter("btn");
			if(btn.equals("Delete"))
			{
				boolean st=TeacherDAO.DeleteById(request.getParameter("tid"));
				
			}
			else if(btn.equals("Edit"))
			{
				 Teacher T=new Teacher();
				  T.setTeacherid(request.getParameter("tid"));
				  T.setTeachername(request.getParameter("tname"));
				  T.setBirthdate(request.getParameter("tdob"));
				  T.setGender(request.getParameter("tgen"));
				  T.setAddress(request.getParameter("tadd"));
				  T.setState(request.getParameter("tstate"));
				  T.setCity(request.getParameter("tcity"));
				  T.setContactnumber(request.getParameter("tcon"));
				  T.setMobilenumber(request.getParameter("tmbl"));
				  T.setEmailid(request.getParameter("tmail"));
				  T.setDateofjoining(request.getParameter("tdoj"));
				  T.setQualification(request.getParameter("tqua"));
				  T.setDesignation(request.getParameter("tdes"));
				  T.setPhotograph(request.getParameter("tpic"));
				  /*Part part=request.getPart("tpic");  
				  String savepath="F:/Java/Test/WebContent/pic";
				  FileUpload F=new FileUpload(part,savepath);
				  T.setPhotograph(F.filename)*/
				  
				boolean st=TeacherDAO.EditById(T);
				
			}
		response.sendRedirect("DisplayAllTeachers");
				
			}catch(Exception e)
	    {
	     out.println(e);	
	    }
		out.flush();
		
		}

	}



