package com.test.dao;


import java.sql.DriverManager;
import java.sql.ResultSet;

import java.sql.Connection;

import com.test.model.Parent;
import com.test.model.Student;


public class ParentDAO {
	static String provider="jdbc:mysql://localhost:3306/StudentInfo";
	
	
	
	
 public static boolean AddNewRecord(Parent P)
 { try{
	 Class.forName("com.mysql.jdbc.Driver").newInstance();
	 Connection cn=DriverManager.getConnection(provider,"root","123");
  String query="insert into parents values('"+P.getParentid()+"','"+P.getParentname()+"','"+P.getStudentsname()+"','"+P.getBirthdate()+"','"+P.getGender()+"','"+P.getAddress()+"','"+P.getState()+"','"+P.getCity()+"','"+P.getContactnumber()+"','"+P.getMobileno()+"','"+P.getEmailid()+"','"+P.getDateofadmission()+"','"+P.getQualification()+"','"+P.getPassword()+"','"+P.getPhotograph()+"')";
  System.out.println(query); 
  boolean st=DBHelper.executeUpdate(cn, query);
    return st;
 }catch(Exception e)
 {System.out.println(e);
 System.out.println(e);
	
	 return false;
 }}

 public static ResultSet DisplayAll()
 { try{
	 Class.forName("com.mysql.jdbc.Driver").newInstance();
	 Connection cn=DriverManager.getConnection(provider,"root","123");
  String query="select * from parents";
  ResultSet rs=DBHelper.executeQuery(cn, query);
  return rs;


 }catch(Exception e)
 {
	 return null;
 }}

 public static ResultSet DisplayById(String pid)
 { try{
	 Class.forName("com.mysql.jdbc.Driver").newInstance();
	 Connection cn=DriverManager.getConnection(provider,"root","123");
  String query="select * from parents where pid='"+pid+"'";
  ResultSet rs=DBHelper.executeQuery(cn, query);
  return rs;


 }catch(Exception e)
 {System.out.println(e);
	 return null;
 }}
 public static boolean DeleteById(String pid)
 { try{
	 Class.forName("com.mysql.jdbc.Driver").newInstance();
	 Connection cn=DriverManager.getConnection(provider,"root","123");
  String query="delete from parents where pid='"+pid+"'";

  boolean st=DBHelper.executeUpdate(cn, query);
    return st;
 }catch(Exception e)
 {System.out.println(e);
	 return false;
 }}
 public static boolean EditById(Parent P)
 { try{
	 Class.forName("com.mysql.jdbc.Driver").newInstance();
	 Connection cn=DriverManager.getConnection(provider,"root","123");
  String query="update Parents set pn='"+P.getParentname()+"',stdn='"+P.getStudentsname()+"',dob='"+P.getBirthdate()+"',pg='"+P.getGender()+"',pa='"+P.getAddress()+"',ps='"+P.getState()+"',pc='"+P.getCity()+"',pcon='"+P.getContactnumber()+"',pmob='"+P.getMobileno()+"',pemail='"+P.getEmailid()+"',stdadm='"+P.getDateofadmission()+"',pq='"+P.getQualification()+"' where pid='"+P.getParentid()+"'";
  System.out.println(query);
  boolean st=DBHelper.executeUpdate(cn, query);
  if(!P.getPhotograph().equals(""))
  {
	query="update parents set ppic='"+P.getPhotograph()+"' where pid='"+P.getParentid()+"'";
	st=DBHelper.executeUpdate(cn, query);
  }
    return st;
 }catch(Exception e)
 {System.out.println(e);
	 return false;
 }}
 public static Parent CheckPassword(String pid,String pwd)
 { 	
	try{
	 Class.forName("com.mysql.jdbc.Driver").newInstance();   
	 Connection cn=DriverManager.getConnection(provider,"root","123");
  String query="select * from parents where pid='"+pid+"' and ppass='"+pwd+"'";
   ResultSet rs=DBHelper.executeQuery(cn, query);
   if(rs.next())
   {
	   Parent P=new Parent();
	   P.setParentid(rs.getString(1));
	   P.setParentname(rs.getString(2));
	   P.setPhotograph(rs.getString(14));
	   return(P);
	   
   }
   
    return null;
 }catch(Exception e)
 {System.out.println(e);
	 return null;


}
 }
 }
