package com.test.dao;



import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;

import com.test.model.Query;



public class QueryDAO {
	
	static String provider="jdbc:mysql://localhost:3306/studentinfo";
	public static boolean addNewQuery(Query Q)
	{try{ Class.forName("com.mysql.jdbc.Driver").newInstance();   
		Connection cn=DriverManager.getConnection(provider,"root","123");
	String query="insert into query (tid,student,querydate,question,status) values('"+Q.getTeacherid()+"','"+Q.getStudentid()+"','"+Q.getQuerydate()+"','"+Q.getQuestion()+"','"+Q.getStatus()+"')";
	System.out.println(query);
	boolean st=DBHelper.executeUpdate(cn, query);
	return st;

	}catch(Exception e)
	{ System.out.println(e);
		return false;
		}
	}

	public static ResultSet displayTeacherQueries(String tid)
	{try{ Class.forName("com.mysql.jdbc.Driver").newInstance();   
	Connection cn=DriverManager.getConnection(provider,"root","123");
	String query="select * from query where tid='"+tid+"'";
	ResultSet rs=DBHelper.executeQuery(cn, query); 
    System.out.println(query);
	return rs;

	}catch(Exception e)
	{ System.out.println(e);
	return null;
	}}
	
	public static boolean updateStatus(Query Q)
	{try{ Class.forName("com.mysql.jdbc.Driver").newInstance();   
	Connection cn=DriverManager.getConnection(provider,"root","123");
    String query="update query set status='"+Q.getStatus()+"' where queryid='"+Q.getQueryid()+"'";
    System.out.println(query);
    boolean ud=DBHelper.executeUpdate(cn, query);
    return ud;

    }catch(Exception e)
    { System.out.println(e);
	    return false;
	}
}
}
