package com.test.view;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.test.dao.StudentDAO;
import com.test.dao.TeacherDAO;

/**
 * Servlet implementation class StudentMarksById
 */
@WebServlet("/StudentMarksById")
public class StudentMarksById extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public StudentMarksById() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		HttpSession ses=request.getSession();
		PrintWriter out=response.getWriter();
		   try{
			ResultSet mid=StudentDAO.DisplayMidTermMarksById(ses.getValue("SEID").toString());
			ResultSet quiz=StudentDAO.DisplayQuizMarksById(ses.getValue("SEID").toString());
			ResultSet mainsem=StudentDAO.DisplayMainSemMarksById(ses.getValue("SEID").toString());
			
			System.out.println("id     "+ses.getValue("SEID").toString()+"bbbbb"+ses.getValue("BRANCH").toString());
			ResultSet sub=TeacherDAO.DisplaySubjects(ses.getValue("BRANCH").toString());
			out.println("<html>");
			out.println("<link rel='stylesheet' type='text/css' href='home2/css/bootstrap.min.css'>");
		     int a=1;
		     sub.next();
		   if(mid.next() && quiz.next() && mainsem.next())
		   {out.println("<table class='table table-bordered'>");
		    out.println("<tr><th>Subject</th><th>Quiz</th><th>Mid Term</th><th>Main Semester</th></tr>");
		    do
		    { 
		    
		    out.println("<tr><td>"+sub.getString(2+a)+"</td><td>"+quiz.getString(a+1)+"</td><td>"+mid.getString(a+1)+"</td><td>"+mainsem.getString(a+1)+"</td</tr>");	
		    	a++;
		    	
		    }while(a!=6);
			  quiz.close();
			  mid.close();
			  mainsem.close();
			  sub.close();
			  
			  
			   out.println("</table>");
		   }
		   else
		   {
			out.println("Record Not Found..");   
		   }
		    out.println("</html>");
		   }catch(Exception e)
		   {out.println(e);
			   
		   }
			}
	
	

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
