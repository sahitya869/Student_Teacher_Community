package com.test.dao;



import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;

import com.test.model.Answer;

public class AnswerDAO {
	
	static String provider="jdbc:mysql://localhost:3306/studentinfo";
	public static boolean addNewAnswer(Answer A)
	{
		try{ Class.forName("com.mysql.jdbc.Driver").newInstance();   
		Connection cn=DriverManager.getConnection(provider,"root","123");
	String query="insert into answer(queryid,teacherid,student,answerdate,question,answer) values('"+A.getQueryid()+"','"+A.getTeacherid()+"','"+A.getStudentid()+"','"+A.getAnswerdate()+"','"+A.getQuestion()+"','"+A.getAnswer()+"')";
	System.out.println(query);
	boolean st=DBHelper.executeUpdate(cn, query);
	return st;

	}catch(Exception e)
	{ System.out.println(e);
		return false;
		}
	}

	public static ResultSet displayQueryAnswers(String sid)
	{try{ Class.forName("com.mysql.jdbc.Driver").newInstance();   
	Connection cn=DriverManager.getConnection(provider,"root","123");
	String query="select * from answer where student='"+sid+"'";
	ResultSet rs=DBHelper.executeQuery(cn, query); 
    System.out.println(query);
	return rs;

	}catch(Exception e)
	{ System.out.println(e);
	return null;
	}}
	
	
}
