package com.test.view;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.test.dao.TeacherDAO;

/**
 * Servlet implementation class SubmitMainSemMarks
 */
@WebServlet("/SubmitMainSemMarks")
public class SubmitMainSemMarks extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SubmitMainSemMarks() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		
		
		String studentid[]=request.getParameterValues("studentid");
		String s1[]=request.getParameterValues("s1");
		String s2[]=request.getParameterValues("s2");
		String s3[]=request.getParameterValues("s3");
		String s4[]=request.getParameterValues("s4");
		String s5[]=request.getParameterValues("s5");
		for(int i=0;i<studentid.length;i++)
		{
		TeacherDAO.AddMainSemMarks(studentid[i], s1[i], s2[i], s3[i], s4[i], s5[i]);
		System.out.println("Marks submitted of-->"+studentid[i]);
		}
		
	}

}
