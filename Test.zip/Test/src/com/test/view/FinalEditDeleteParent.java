package com.test.view;



import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.test.dao.ParentDAO;
import com.test.model.Parent;

/**
 * Servlet implementation class FinalEditDeleteParent
 */
@WebServlet("/FinalEditDeleteParent")
public class FinalEditDeleteParent extends HttpServlet {
	private static final long serialVersionUID = 1L;

    /**
     * @see HttpServlet#HttpServlet()
     */
    public FinalEditDeleteParent() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
    PrintWriter out=response.getWriter();
		try{
		String btn=request.getParameter("btn");
		if(btn.equals("Delete"))
		{
			boolean st=ParentDAO.DeleteById(request.getParameter("pid"));

		}
		else if(btn.equals("Edit"))
		{
			 Parent P=new Parent();
			  P.setParentid(request.getParameter("pid"));
			  P.setParentname(request.getParameter("pn"));
			  P.setStudentsname(request.getParameter("stdn"));
			  P.setBirthdate(request.getParameter("dob"));
			  P.setGender(request.getParameter("pg"));
			  P.setAddress(request.getParameter("pa"));
			  P.setState(request.getParameter("ps"));
			  P.setCity(request.getParameter("pc"));
			  P.setContactnumber(request.getParameter("pcon"));
			  P.setMobileno(request.getParameter("pmob"));
			  P.setEmailid(request.getParameter("pemail"));
			  P.setDateofadmission(request.getParameter("stdadm"));
			  P.setQualification(request.getParameter("pq"));
			  P.setPhotograph(request.getParameter("ppic"));
			  
			boolean st=ParentDAO.EditById(P);

		}
	response.sendRedirect("DisplayAllParents");

		}catch(Exception e)
    {
     out.println(e);
    }
	out.flush();

	}

}

