package com.test.dao;

import java.sql.Connection;
import java.sql.DriverManager;

import com.test.model.Branch;

public class TeacherRecordDAO {
	static String provider="jdbc:mysql://localhost:3306/studentinfo";

	public static boolean AddNewRecord(Branch B) {
		// TODO Auto-generated method stub
		
		{try{
			Class.forName("com.mysql.jdbc.Driver").newInstance();
			Connection cn=DriverManager.getConnection(provider,"root","123");
			
			String query="insert into trecord value('"+B.getSubjectname()+"','"+B.getTeacherid()+"','"+B.getBranchname()+"','"+B.getSemester()+"','"+B.getPhotograph()+"')";
			System.out.println(query);
			
			 boolean st=DBHelper.executeUpdate(cn, query);
			 return st;
		}	catch(Exception e)
		 {System.out.println(e);
			 return false;
		 }

	}}}

