package com.test.model;

public class Register {
	
	private String yourid;

	public String getYourid() {
		return yourid;
	}

	public void setYourid(String yourid) {
		this.yourid = yourid;
	}

}
