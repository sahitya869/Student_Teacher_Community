package com.test.view;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.test.dao.StudentDAO;
import com.test.model.Student;

/**
 * Servlet implementation class FinalEditDeleteStudent
 */
@WebServlet("/FinalEditDeleteStudent")
public class FinalEditDeleteStudent extends HttpServlet {
	private static final long serialVersionUID = 1L;

    /**
     * Default constructor. 
     */
    public FinalEditDeleteStudent() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub

		PrintWriter out=response.getWriter();
		try{
		String btn=request.getParameter("btn");
		if(btn.equals("Delete"))
		{
			boolean st=StudentDAO.DeleteById(request.getParameter("sid"));
			
		}
		else if(btn.equals("edit"))
		{
			 Student S=new Student();
			  S.setStudentid(request.getParameter("sid"));
			  S.setStudentname(request.getParameter("sn"));
			  S.setFathersname(request.getParameter("sfn"));
			  S.setBirthDate(request.getParameter("dob"));
			  S.setGender(request.getParameter("sg"));
			  S.setAddress(request.getParameter("sa"));
			  S.setState(request.getParameter("ss"));
			  S.setCity(request.getParameter("sc"));
			  S.setFathersnumber(request.getParameter("scon"));
			  S.setMobilenumber(request.getParameter("smob"));
			  S.setEmailid(request.getParameter("smail"));
			  S.setYear(request.getParameter("syear"));
			  S.setBranch(request.getParameter("sbranch"));
			  S.setPhotograph(request.getParameter("spic"));
			  S.setPassword(request.getParameter("spass"));
			  
			  System.out.println("ABC:"+request.getParameter("spic"));
			  boolean st=StudentDAO.EditById(S);
			
		}
		
		
		
		
	response.sendRedirect("DisplayAllStudents");
			
		}catch(Exception e)
    {
     out.println(e);	
    }
	out.flush();
	
	}

}
