package com.test.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;

import com.test.dao.DBHelper;
import com.test.model.Student;


public class StudentDAO {
	
	static String provider="jdbc:mysql://localhost:3306/studentinfo";
	
	
	
	
	public static boolean AddNewRecord(Student S)
	{try{
		Class.forName("com.mysql.jdbc.Driver").newInstance();
		Connection cn=DriverManager.getConnection(provider,"root","123");
		
		String query="insert into students value('"+S.getStudentid()+"','"+S.getStudentname()+"','"+S.getFathersname()+"','"+S.getBirthDate()+"','"+S.getGender()+"','"+S.getAddress()+"','"+S.getState()+"','"+S.getCity()+"','"+S.getFathersnumber()+"','"+S.getMobilenumber()+"','"+S.getEmailid()+"','"+S.getYear()+"','"+S.getBranch()+"','"+S.getPhotograph()+"','"+S.getPassword()+"')";
		System.out.println(query);
		
		 boolean st=DBHelper.executeUpdate(cn, query);
		 return st;
	}	catch(Exception e)
	 {System.out.println(e);
		 return false;
	 }

}
	public static ResultSet DisplayAll()
	 { try{
		 Class.forName("com.mysql.jdbc.Driver").newInstance();   
		 Connection cn=DriverManager.getConnection(provider,"root","123");
	  String query="select * from students";
	  ResultSet rs=DBHelper.executeQuery(cn, query);
	  return rs;
		 
		 
	 }catch(Exception e)
	 {System.out.println(e);
		 return null;
	 }}
	public static ResultSet DisplayById(String sid)
	 { try{
		 Class.forName("com.mysql.jdbc.Driver").newInstance();   
		 Connection cn=DriverManager.getConnection(provider,"root","123");
	  String query="select * from students where student='"+sid+"'";
	  ResultSet rs=DBHelper.executeQuery(cn, query);
	  return rs;
		 
		 
	 }catch(Exception e)
	 {System.out.println(e);
		 return null;
	 }
	 }
	public static ResultSet DisplayMidTermMarksById(String sid)
	 { try{
		 Class.forName("com.mysql.jdbc.Driver").newInstance();   
		 Connection cn=DriverManager.getConnection(provider,"root","123");
	  String query="select * from midtermmarks where StudentID='"+sid+"'";
	  ResultSet rs=DBHelper.executeQuery(cn, query);
	  return rs;
		 
		 
	 }catch(Exception e)
	 {System.out.println(e);
		 return null;
	 }
	 }

 public static boolean DeleteById(String sid)
 { try{
	 Class.forName("com.mysql.jdbc.Driver").newInstance();   
	 Connection cn=DriverManager.getConnection(provider,"root","123");
  String query="delete from students where student='"+sid+"'";
   
  boolean st=DBHelper.executeUpdate(cn, query);
    return st;
 }catch(Exception e)
 {System.out.println(e);
	 return false;
 }}
 public static boolean EditById(Student S)

 
 { try{
	 Class.forName("com.mysql.jdbc.Driver").newInstance();   
	 Connection cn=DriverManager.getConnection(provider,"root","123");
  String query="update students set ename='"+S.getStudentname()+"',fname='"+S.getFathersname()+"',dob='"+S.getBirthDate()+"',gender='"+S.getGender()+"',address='"+S.getAddress()+"',state='"+S.getState()+"',city='"+S.getCity()+"',fathersnumber='"+S.getFathersnumber()+"',mobilenumber='"+S.getMobilenumber()+"',emailid='"+S.getEmailid()+"',year='"+S.getYear()+"',branch='"+S.getBranch()+"',password='"+S.getPassword()+"' where student='"+S.getStudentid()+"'";
  System.out.println(query);   
  boolean st=DBHelper.executeUpdate(cn, query);
  if(!S.getPhotograph().equals(""))
  {
	query="update students set photograph='"+S.getPhotograph()+"' where student='"+S.getStudentid()+"'";
	st=DBHelper.executeUpdate(cn, query);
  }
    return st;
 }catch(Exception e)
 {System.out.println(e);
	 return false;
 }}
 
 
 

 public static Student CheckPassword(String sid,String pwd)
 { 	
	try{
	 Class.forName("com.mysql.jdbc.Driver").newInstance();   
	 Connection cn=DriverManager.getConnection(provider,"root","123");
  String query="select * from students where student='"+sid+"' and password='"+pwd+"'";
   ResultSet rs=DBHelper.executeQuery(cn, query);
   if(rs.next())
   {
	   Student S=new Student();
	   S.setStudentid(rs.getString(1));
	   S.setStudentname(rs.getString(2));
	   S.setPhotograph(rs.getString(14));
	   S.setBranch(rs.getString(13));
	   return(S);
	   
   }
   
    return null;
 }catch(Exception e)
 {System.out.println(e);
	 return null;


}}
	
	
	
	
	 public static ResultSet displayTeacher() {
			// TODO Auto-generated method stub
			

			try{ Class.forName("com.mysql.jdbc.Driver").newInstance();   
			Connection cn=DriverManager.getConnection(provider,"root","123");
			String query="select tid,tname,tpic from teachers";
			ResultSet rs=DBHelper.executeQuery(cn, query); 

			return rs;

			}catch(Exception e)
			{ System.out.println(e);
			return null;
			}}
	public static ResultSet FillById(String sid) {
		// TODO Auto-generated method stub
		{ try{
			 Class.forName("com.mysql.jdbc.Driver").newInstance();   
			 Connection cn=DriverManager.getConnection(provider,"root","123");
		  String query="select * from students where student='"+sid+"'";
		  ResultSet rs=DBHelper.executeQuery(cn, query);
		  return rs;
			 
			 
		 }catch(Exception e)
		 {System.out.println(e);
			 return null;
		 }
		 }
	}
	
		public static ResultSet DisplayQuizMarksById(String sid)
		 { try{
			 Class.forName("com.mysql.jdbc.Driver").newInstance();   
			 Connection cn=DriverManager.getConnection(provider,"root","123");
		  String query="select * from quizmarks where StudentID='"+sid+"'";
		  ResultSet rs=DBHelper.executeQuery(cn, query);
		  return rs;
			 
			 
		 }catch(Exception e)
		 {System.out.println(e);
			 return null;
		 }
		 }
		public static ResultSet DisplayMainSemMarksById(String sid)
		 { try{
			 Class.forName("com.mysql.jdbc.Driver").newInstance();   
			 Connection cn=DriverManager.getConnection(provider,"root","123");
		  String query="select * from mainsemmarks where StudentID='"+sid+"'";
		  ResultSet rs=DBHelper.executeQuery(cn, query);
		  return rs;
			 
			 
		 }catch(Exception e)
		 {System.out.println(e);
			 return null;
		 }
		 }}