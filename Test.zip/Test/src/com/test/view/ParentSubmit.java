package com.test.view;

import java.io.IOException;

import java.io.PrintWriter;
import org.softech.FileUpload;

import com.test.dao.ParentDAO;
import com.test.model.Parent;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

/**
 * Servlet implementation class ParentSubmit
 */
@WebServlet("/ParentSubmit")
/*@MultipartConfig(fileSizeThreshold=1024*1024*10,//2MB
maxFileSize=1024*1024*20,//10MB
maxRequestSize=1024*1024*50)*/

public class ParentSubmit extends HttpServlet {
	private static final long serialVersionUID = 1L;

    /**
     * @see HttpServlet#HttpServlet()
     */
    public ParentSubmit() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub

  PrintWriter out=response.getWriter();
  Parent P=new Parent();
  P.setParentid(request.getParameter("pid"));
  P.setParentname(request.getParameter("pn"));
  P.setStudentsname(request.getParameter("stdn"));
  P.setBirthdate(request.getParameter("dob"));
  P.setGender(request.getParameter("pg"));
  P.setAddress(request.getParameter("pa"));
  P.setState(request.getParameter("ps"));
  P.setCity(request.getParameter("pc"));
  P.setContactnumber(request.getParameter("pcon"));
  P.setMobileno(request.getParameter("pmob"));
  P.setEmailid(request.getParameter("pemail"));
  P.setDateofadmission(request.getParameter("stdadm"));
  P.setQualification(request.getParameter("pq"));
  P.setPassword(request.getParameter("ppass"));
  P.setPhotograph(request.getParameter("ppic"));
 /* Part part=request.getPart("ppic");
  String savepath="C:/Users/HP/workspace/Parent/WebContent/pic";
  FileUpload F=new FileUpload(part,savepath);
  P.setPhotograph(F.filename);*/

  boolean st=ParentDAO.AddNewRecord(P);
  out.println("<html>");
  if(st)
  {out.println("<h3><font color=green>Record Submitted...<br><a href=ParentInterface >Click Here to Add More Records..</a></font></h3>");
	}
  else
  {
	  out.println("<h3><font color=red>Failed to Submit Record<br><a href=ParentInterface>Click Here to Add More Records..</a></font></h3>");

  }

  out.println("</html>");
  out.flush();

	}

}
