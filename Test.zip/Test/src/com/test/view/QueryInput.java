package com.test.view;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class QueryInput
 */
@WebServlet("/QueryInput")
public class QueryInput extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public QueryInput() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		
		
		
		HttpSession ses=request.getSession(false);
		  String tid=request.getParameter("tid");
		  
		   String ssid= ses.getValue("SEID").toString();
	        PrintWriter out=response.getWriter();
		    out.println("<script src=asset/jquery-2.2.1.min.js></script>");
			  out.println("<script src=query.js></script>");
			  out.println("<html>");
			  out.println("<link rel='stylesheet' type='text/css' href='home2/css/bootstrap.min.css'>");
			  out.println("<form action=QuerySubmit method=get >");
			 
			  
			  
			  out.println("<h4 >Teacher ID :<input type=text value="+tid+" readonly name=tid>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Student ID :<input type=text value="+ssid+" readonly name=sid>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Current Date:<input type=text name=cd id=cd ></h4><hr>");
			  out.println("<table class='table table-bordered'>");
			 
			  
			  out.println("<tr><td><b><i>Question:</i></b></td><td><textarea name=que rows=5 cols=50></textarea></td></tr>");
			  out.println("<tr><td></td><td><input type=submit class='btn btn-success'></td></tr>");
			  out.println("</table></form></html>");
			  out.flush();
	}

}
