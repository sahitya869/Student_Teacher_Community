package com.test.view;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.test.dao.TeacherDAO;

import java.sql.ResultSet;
/**
 * Servlet implementation class UpdateDeleteTeacher
 */
@WebServlet("/UpdateDeleteTeacher")
public class UpdateDeleteTeacher extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UpdateDeleteTeacher() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter out=response.getWriter();
		try{
		String tid=request.getParameter("tid");
		ResultSet rs=TeacherDAO.DisplayById(tid);
		if(rs.next())
		{
			 out.println("<html><head><link rel='stylesheet' type='text/css' href='home2/css/bootstrap.min.css'></head><form action=FinalEditDeleteTeacher>");
		       out.println("<a href=DisplayAllTeacher class='btn btn-success'>List of Teachers</a><br>");
		       out.println("<table cellpadding=15 cellspacing=15 class='table table-bordered'><tr><td>");
		       out.println("<table class='table table-bordered'><caption><h3>Teacher Registration</h3></caption>");
		       out.println("<tr><td><b><i>Teacher Id:</i></b></td><td><input type=text name=tid size=40 value="+rs.getString(1)+" readonly=true></td></tr>");
		       out.println("<tr><td><b><i>Name:</i></b></td><td><input type=text name=tname size=40 value="+rs.getString(2)+"></td></tr>");
		       
		       out.println("<tr><td><b><i>Birth Date:</i></b></td><td><input type=date name=tdob size=40 value="+rs.getString(3)+"></td></tr>");
		       if(rs.getString(4).equals("Male"))
		       out.println("<tr><td><b><i>Gender:</i></b></td><td><input type=radio name=tgen value=Male checked>Male<input type=radio name=tgen value=Female>Female</td></tr>");
		       else
		       out.println("<tr><td><b><i>Gender:</i></b></td><td><input type=radio name=tgen value=Male>Male<input type=radio name=tgen value=Female checked>Female</td></tr>");
		       
		       out.println("<tr><td><b><i>Address:</i></b></td><td><textarea  name=tadd rows=3 cols=40>"+rs.getString(5)+"</textarea></td></tr>");
		       out.println("<tr><td><b><i>State:</i></b></td><td><input type=text name=tstate size=40 value="+rs.getString(6)+"></td></tr>");
		       out.println("<tr><td><b><i>City:</i></b></td><td><input type=text name=tcity size=40 value="+rs.getString(7)+"></td></tr>");
		      
		       out.println("<tr><td><b><i>Contact No:</i></b></td><td><input type=text name=tcon size=40 value="+rs.getString(8)+"></td></tr>");
		       out.println("<tr><td><b><i>Mobile:</i></b></td><td><input type=text name=tmbl size=40 value="+rs.getString(9)+"></td></tr>");
		       out.println("<tr><td><b><i>Email Id:</i></b></td><td><input type=text name=tmail size=40 value="+rs.getString(10)+"></td></tr>");
		       out.println("<tr><td><b><i>Joining Date:</i></b></td><td><input type=date name=tdoj size=40 value="+rs.getString(11)+"></td></tr>");
		       out.println("<tr><td><b><i>Qualification:</i></b></td><td><textarea  name=tqua rows=3 cols=40 >"+rs.getString(12)+"</textarea></td></tr>");
		       out.println("<tr><td><b><i>Designation:</i></b></td><td><select name=tdes><option value="+rs.getString(13)+"></option><option value=\"Director\">Director</option><option value=\"Professor\">Professor</option><option value=\"Assistent Professor\">Assistent Professor</option></select></td></tr>");
		       out.println("<tr><td><b><i>Branch:</i></b></td><td><select name=branch><option value=\"CSE\">CSE</option><option value=\"IT\">IT</option></select></td></tr>");
		       
		        
		    
		       out.println("</table></td>");
		       out.println("<th valign=middle><img src=pic/"+rs.getString(15)+" width=150 height=150><br><br><input type=file name=tpic></th></tr></table>");
			
		       out.println("<input type=submit class='btn btn-info' name=btn value=Edit>&nbsp;&nbsp;<input type=submit class='btn btn-success' name=btn value=Delete>");
		}
		else
		{
			out.println("not found...");
		}
		}catch(Exception e)
		{out.println(e);
			
		}
		
		
		
		
		}

	}
