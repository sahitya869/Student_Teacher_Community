package com.test.model;

public class Parent {
 private String parentid;
 private String parentname;
 private String studentsname;
 private String birthdate;
 private String gender;
 private String address;
 private String state;
 private String city;
 private String contactnumber;
 private String mobileno;
 private String emailid;
 private String dateofadmission;
 private String qualification;

 public String getParentid() {
	return parentid;
}
public void setParentid(String parentid) {
	this.parentid = parentid;
}
public String getParentname() {
	return parentname;
}
public void setParentname(String parentname) {
	this.parentname = parentname;
}
public String getStudentsname() {
	return studentsname;
}
public void setStudentsname(String studentsname) {
	this.studentsname = studentsname;
}
public String getBirthdate() {
	return birthdate;
}
public void setBirthdate(String birthdate) {
	this.birthdate = birthdate;
}
public String getGender() {
	return gender;
}
public void setGender(String gender) {
	this.gender = gender;
}
public String getAddress() {
	return address;
}
public void setAddress(String address) {
	this.address = address;
}
public String getState() {
	return state;
}
public void setState(String state) {
	this.state = state;
}
public String getCity() {
	return city;
}
public void setCity(String city) {
	this.city = city;
}
public String getContactnumber() {
	return contactnumber;
}
public void setContactnumber(String contactnumber) {
	this.contactnumber = contactnumber;
}
public String getMobileno() {
	return mobileno;
}
public void setMobileno(String mobileno) {
	this.mobileno = mobileno;
}
public String getEmailid() {
	return emailid;
}
public void setEmailid(String emailid) {
	this.emailid = emailid;
}

public String getDateofadmission() {
	return dateofadmission;
}
public void setDateofadmission(String dateofadmission) {
	this.dateofadmission = dateofadmission;
}
public String getQualification() {
	return qualification;
}
public void setQualification(String qualification) {
	this.qualification = qualification;
}
public String getPassword() {
	return password;
}
public void setPassword(String password) {
	this.password = password;
}
public String getPhotograph() {
	return photograph;
}
public void setPhotograph(String photograph) {
	this.photograph = photograph;
}
private String password;
 private String photograph;



}
