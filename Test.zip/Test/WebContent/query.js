$(function(){
	var d=new Date();
	var cd=d.getFullYear()+"/"+(d.getMonth()+1)+"/"+d.getDate();
	$("#cd").val(cd);

	
});