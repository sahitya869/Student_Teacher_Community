package com.test.view;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.test.dao.StudentDAO;

/**
 * Servlet implementation class AskQuestion
 */
@WebServlet("/AskQuestion")
public class AskQuestion extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AskQuestion() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		PrintWriter out=response.getWriter();
	      try{
	       out.println("<html>");
	       out.println("<link rel='stylesheet' type='text/css' href='home2/css/bootstrap.min.css'>");
	       ResultSet rs=StudentDAO.displayTeacher();
	       String sid=request.getParameter("sid");
	       String ssid=sid;
	       if(rs.next())
	       { out.println("<caption><b><i><h1>List of Teachers</h1></i></b></caption>");
	       out.println("<centre><table class='table table-bordered'>");
	      
	       do
	       {
	    	   
	    	   out.println("<tr><td><a href=QueryInput?tid="+rs.getString(1)+"><img src=pic/"+rs.getString(3)+" width=200 height=200><br>"+rs.getString(2)+"."+rs.getString(3)+"</a></td>");
	    	   rs.next();
	    	   out.println("<td><a href=QueryInput?tid="+rs.getString(1)+"><img src=pic/"+rs.getString(3)+" width=200 height=200><br>"+rs.getString(2)+"."+rs.getString(3)+"</a></td>");
	    	   rs.next();
	    	   out.println("<td><a href=QueryInput?tid="+rs.getString(1)+"><img src=pic/"+rs.getString(3)+" width=200 height=200><br>"+rs.getString(2)+"."+rs.getString(3)+"</a></td></tr>");
	    	   
	       
	       }while(rs.next());
	       out.println("</table></centre>");
	       }
	       else
	       {
	    	 out.println("<b><i>No Teacher Available !!!</i></b>");  
	       }
	       out.println("</html>");
	       out.flush();
	      }catch(Exception e){}
	}

}