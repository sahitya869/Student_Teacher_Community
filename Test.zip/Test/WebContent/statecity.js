 $(document).ready(
        function() {

        	 $.getJSON("FetchStatesJSON", function(json){
        		
        		 
                 $('#ss').empty();
                
        		 
                 $('#ss').append($('<option>').text("Select"));
                
        		 
                 $.each(json, function(i, item){
                        
                	 $('#ss').append($('<option>').text(item.STATENAME).attr('value',item.STATENAME));
                 });
             });
      
 $("#ss").change(function(){
 	$.getJSON("FetchAllCitiesByIdJSON",{stid:$('#ss').val()}, function(json){
         $('#sc').empty();
         $('#sc').append($('<option>').text("Select"));
         $.each(json, function(i, item){
                 $('#sc').append($('<option>').text(item.CITYNAME).attr('value', item.CITYNAME));
         });
     }); 
});
        });