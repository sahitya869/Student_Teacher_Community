package com.test.view;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import org.softech.FileUpload;

import com.test.dao.TeacherRecordDAO;
import com.test.model.Branch;

import com.test.model.Teacher;

/**
 * Servlet implementation class TeacherRecordSubmit
 */
@WebServlet("/TeacherRecordSubmit")
@MultipartConfig(fileSizeThreshold=1024*1024*2,//2MB
maxFileSize=1024*1024*10,//10MB
maxRequestSize=1024*1024*50)
public class TeacherRecordSubmit extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public TeacherRecordSubmit() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		 PrintWriter out=response.getWriter();
		  
		  Branch B=new Branch();
		  B.setSubjectname(request.getParameter("sub"));
		  B.setTeacherid(request.getParameter("tid"));		 
		  B.setBranchname(request.getParameter("bra"));
		  B.setSemester(request.getParameter("sem"));
		 
		  //B.setPhotograph(request.getParameter("pic"));
		  Part part=request.getPart("pic"); 
		  String savepath="F:/Java/Test/WebContent/pic";
		 FileUpload F=new FileUpload(part,savepath);
		 B.setPhotograph(F.filename);
		 
		 
		  boolean st=TeacherRecordDAO.AddNewRecord(B);
		  out.println("<html>");
		  if(st)
		  {out.println("<h3><font color=green>Record Submitted<br><a href=StudentInterface>Click Here to Add More StudentInfo..</a></font></h3>");
			}
		  else
		  {
			  out.println("<h3><font color=red>Record Not Submitted<br><a href=StudentInterface>Click Here to Add More StudentInfo..</a></font></h3>");  
			  
		  }  
			  
		  out.println("</html>");
		  out.flush();
		  
		  
		  
		
		
	}

}
