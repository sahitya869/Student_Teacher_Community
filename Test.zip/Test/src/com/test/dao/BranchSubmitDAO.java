package com.test.dao;

import java.sql.Connection;
import java.sql.DriverManager;

import com.test.model.Branch;

public class BranchSubmitDAO {
	static String provider="jdbc:mysql://localhost:3306/studentinfo";
	public static boolean AddNewRecord(Branch B) { 	
		try{
			 Class.forName("com.mysql.jdbc.Driver").newInstance();   
			 Connection cn=DriverManager.getConnection(provider,"root","123");
		  String query="insert into branchsubmit values('"+B.getBranchname()+"','"+B.getSemester()+"','"+B.getSubjectid()+"','"+B.getSubjectname()+"','"+B.getStatus()+"')";
		   System.out.println(query);
		  boolean st=DBHelper.executeUpdate(cn, query);
		    return st;
		 }catch(Exception e)
		 {System.out.println(e);
			 return false;
		 }}
		
		
		
		
	}
