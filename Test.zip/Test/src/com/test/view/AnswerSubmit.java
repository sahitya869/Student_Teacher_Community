package com.test.view;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.test.dao.AnswerDAO;
import com.test.dao.QueryDAO;
import com.test.model.Answer;
import com.test.model.Query;

/**
 * Servlet implementation class AnswerSubmit
 */
@WebServlet("/AnswerSubmit")
public class AnswerSubmit extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AnswerSubmit() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter out=response.getWriter();
		Answer A=new Answer();
		A.setQueryid(request.getParameter("qid"));
		A.setTeacherid(request.getParameter("tid"));
		A.setStudentid(request.getParameter("sid"));
		A.setAnswerdate(request.getParameter("cd"));
		A.setQuestion(request.getParameter("que"));
		A.setAnswer(request.getParameter("ans"));
		
		String q=request.getParameter("qid");
		
		boolean st=AnswerDAO.addNewAnswer(A);
		if(st)
		  {
			  out.println("<font color=green>Answer Submitted.....</font>");
			  Query Q=new Query();
			  Q.setQueryid(q);
			  Q.setStatus("Answered");
			  boolean ud=QueryDAO.updateStatus(Q);
				if(ud)
				{
					System.out.println("Query Status Updated");
				}
				 else
				  {out.println("Failed to Update Query Status...");
					  
				  }
			  
		  }
		  else
		  {out.println("Fail to Submit Query...");
			  
		  }
		out.flush();
		
	}

}
