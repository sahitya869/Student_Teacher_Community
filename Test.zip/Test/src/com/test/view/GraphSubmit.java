package com.test.view;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import org.softech.FileUpload;



import com.test.dao.GraphDAO;
import com.test.model.GraphMarks;

/**
 * Servlet implementation class GraphSubmit
 */
@WebServlet("/GraphSubmit")
@MultipartConfig(fileSizeThreshold=1024*1024*2,//2MB
maxFileSize=1024*1024*10,//10MB
maxRequestSize=1024*1024*50)
public class GraphSubmit extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public GraphSubmit() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		
		PrintWriter out=response.getWriter();
		  GraphMarks G=new GraphMarks();
		  G.setStudentid(request.getParameter("gsid"));
		  
		  
		  Part part=request.getPart("gspic"); 
		  String savepath="F:/Java/Test/WebContent/pic";
		  FileUpload F=new FileUpload(part,savepath);
		  G.setPic(F.filename);
		 
		   boolean st=GraphDAO.AddNewRecord(G);
		  out.println("<html>");
		  if(st)
		  {out.println("<h3><font color=green>Record Submitted</font></h3>");

		  }
		  else
		  {
			  out.println("<h3><font color=red>Fail to Record Submitted</font></h3>");  
		  }  
			  
		  out.println("</html>");
		  out.flush();
	}}