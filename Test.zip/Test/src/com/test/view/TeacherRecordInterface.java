package com.test.view;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class TeacherRecordInterface
 */
@WebServlet("/TeacherRecordInterface")
public class TeacherRecordInterface extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public TeacherRecordInterface() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		
		PrintWriter out=response.getWriter();
		
		out.println("<table><caption><h3>Student Registration</h3></caption>");
		
		 

		out.println("<html><form action=TeacherRecordSubmit method=post enctype=multipart/form-data>");
		  
		   
		   out.println("<html><form action=TeacherRecordSubmit>");
	       
		   out.println("<tr><td><b><i>Subject Name:</i></b></td><td><input type=text name=sub size=40></td></tr>");
	       out.println("<tr><td><b><i>Teacher Id:</i></b></td><td><input type=text name=tid size=40></td></tr>");
	       out.println("<tr><td><b><i>Branch:</i></b></td><td><input type=text name=bra size=40></td></tr>");
	       out.println("<tr><td><b><i>Semester:</i></b></td><td><input type=text name=sem size=40></td></tr>");
	       out.println("<tr><td><b><i>Photograph:</i></b></td><td><input type=file name=pic size=40></td></tr>");
		      
	       out.println("<tr><td><input type=submit></td><td><input type=reset></td></tr>");
	       
		
	}

}
