package com.test.view;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.test.dao.StudentDAO;

/**
 * Servlet implementation class UpdateDeleteStudent
 */
@WebServlet("/UpdateDeleteStudent")
public class UpdateDeleteStudent extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UpdateDeleteStudent() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter out=response.getWriter();
		try{
		String sid=request.getParameter("sid");
		ResultSet rs=StudentDAO.DisplayById(sid);
		if(rs.next())
		{
			out.println("<html><head><link rel='stylesheet' type='text/css' href='home2/css/bootstrap.min.css'></head><form action=FinalEditDeleteStudent>");
		       out.println("<a href=DisplayAllStudents class='btn btn-success'>List of Students</a><br>");
		       out.println("<table cellpadding=15 cellspacing=15 class='table table-bordered'><tr><td>");
		       out.println("<table class='table table-bordered'><caption><h3>Student Register</h3></caption>");
		       out.println("<tr><td><b><i>Student Id:</i></b></td><td><input type=text name=sid size=40 value="+rs.getString(1)+" readonly=true></td></tr>");
		       out.println("<tr><td><b><i>Name:</i></b></td><td><input type=text name=sn size=40 value="+rs.getString(2)+"></td></tr>");
		       out.println("<tr><td><b><i>Father's Name:</i></b></td><td><input type=text name=sfn size=40 value="+rs.getString(3)+"></td></tr>");
		       out.println("<tr><td><b><i>Birth Date:</i></b></td><td><input type=date name=dob size=40 value="+rs.getString(4)+"></td></tr>");
		       if(rs.getString(5).equals("Male"))
		       out.println("<tr><td><b><i>Gender:</i></b></td><td><input type=radio name=sg value=Male checked>Male<input type=radio name=sg value=Female>Female</td></tr>");
		       else
		       out.println("<tr><td><b><i>Gender:</i></b></td><td><input type=radio name=sg value=Male>Male<input type=radio name=sg value=Female checked>Female</td></tr>");
		       
		       out.println("<tr><td><b><i>Address:</i></b></td><td><textarea  name=sa rows=3 cols=40>"+rs.getString(6)+"</textarea></td></tr>");
		       out.println("<tr><td><b><i>State:</i></b></td><td><input type=text name=ss size=40 value="+rs.getString(7)+"></td></tr>");
		       out.println("<tr><td><b><i>City:</i></b></td><td><input type=text name=sc size=40 value="+rs.getString(8)+"></td></tr>");
		      
		       out.println("<tr><td><b><i>fathers No:</i></b></td><td><input type=text name=scon size=40 value="+rs.getString(9)+"></td></tr>");
		       out.println("<tr><td><b><i>Mobile:</i></b></td><td><input type=text name=smob size=40 value="+rs.getString(10)+"></td></tr>");
		       out.println("<tr><td><b><i>Email Id:</i></b></td><td><input type=text name=smail size=40 value="+rs.getString(11)+"></td></tr>");
		       out.println("<tr><td><b><i>Year:</i></b></td><td><input type=text name=syear size=40 value="+rs.getString(12)+"></td></tr>");
		       out.println("<tr><td><b><i>Branch:</i></b></td><td><select name=sbranch><option value=\"CSE\">CSE</option><option value=\"IT\">IT</option></select></td></tr>");
		       out.println("<tr><td><b><i>Password:</i></b></td><td><input type=password name=spass size=40 value="+rs.getString(15)+"></td></tr>"); 
			   
		       out.println("</table></td>");
		       out.println("<th valign=middle><img src=pic/"+rs.getString(14)+" width=250 height=250><br><br><input type=file name=spic></th></tr></table>");
		        
		       out.println("<input class='btn btn-success' type=submit name=btn value=edit>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type=submit class='btn btn-primary' name=btn value=Delete>");
		}
		else
		{
			out.println("not found...");
		}
		}catch(Exception e)
		{out.println(e);
			
		}
		
		
		
		
		}

	}
