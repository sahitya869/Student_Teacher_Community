package com.test.view;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class BranchInterface
 */
@WebServlet("/BranchInterface")
public class BranchInterface extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public BranchInterface() {
        super();
        // TODO Auto-generated constructor stub
    }
                   
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		PrintWriter out=response.getWriter();
		
		  out.println("<script src=asset/jquery-2.2.1.min.js></script>");
	       out.println("<script src=branch.js></script>");
	       
	       
		
		out.println("<html><head><link rel='stylesheet' type='text/css' href='home2/css/bootstrap.min.css'></head><form action=BranchSubmit>");
	    out.println("<caption><h3>Branch Information</h3></caption><table class='table table-bordered'>");
		
	    out.println("<tr><td><b><i>Branch Name:</i></b></td><td><select name=bn id=bn></select></td></tr>");
	    out.println("<tr><td><b><i>Semester:</i></b></td><td><select name=sem id=sem></select></td></tr>");
	    out.println("<tr><td><b><i>Subject Id:</i></b></td><td><select name=si id=si></select></td></tr>");
	    //out.println("<tr><td><b><i>Subject Name:</i></b></td><td><select name=sn id=sn></select></td></tr>");
	    out.println("<tr><td><b><i>Subject Name:</i></b></td><td><input type=text name=sn size=40></td></tr>");  
	    out.println("<tr><td><b><i>Status:</i></b></td><td><input type=radio name=st value=Theory>Theory<input type=radio value=Practical>Practical</td></tr>");
	    out.println("<tr><td><input type=submit class='btn btn-info'></td><td><input type=reset class='btn btn-danger'></td></tr>");
	    out.println("</table></form></html>");
		
		
		
	}

}
