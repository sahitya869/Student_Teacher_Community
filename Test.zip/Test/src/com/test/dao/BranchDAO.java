package com.test.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;


public class BranchDAO {
	static String provider="jdbc:mysql://localhost:3306/studentinfo";

	public static ResultSet DisplayAllBranch() {
		// TODO Auto-generated method stub
		
		
		
		
		try{
			 Class.forName("com.mysql.jdbc.Driver").newInstance();   
			 Connection cn=DriverManager.getConnection(provider,"root","123");
		  String query="select * from branch";
		  ResultSet rs=DBHelper.executeQuery(cn, query);
		  
		  
		   
		    return rs;
		 }catch(Exception e)
		 {System.out.println(e);
			 return null;
		 }}

	public static ResultSet DisplayAllSemester(String sid) {
		
		try{
			 Class.forName("com.mysql.jdbc.Driver").newInstance();   
			 Connection cn=DriverManager.getConnection(provider,"root","123");
		  String query="select * from semester where branchid='"+sid+"'";
		  ResultSet rs=DBHelper.executeQuery(cn, query);
		  
		  
		   
		    return rs;
		 }catch(Exception e)
		 {System.out.println(e);
			 return null;
		 }}

	public static ResultSet DisplayAllSubjectNo(String sno) {
		
		try{
			 Class.forName("com.mysql.jdbc.Driver").newInstance();   
			 Connection cn=DriverManager.getConnection(provider,"root","123");
		  String query="select * from subjectcode where semesterid='"+sno+"'";
		  ResultSet rs=DBHelper.executeQuery(cn, query);
		  
		  
		   
		    return rs;
		 }catch(Exception e)
		 {System.out.println(e);
			 return null;
		 }}

	public static ResultSet DisplayAllSubjectName(String sna) {
		
		try{
			 Class.forName("com.mysql.jdbc.Driver").newInstance();   
			 Connection cn=DriverManager.getConnection(provider,"root","123");
		  String query="select * from subjectname where subjectid='"+sna+"'";
		  ResultSet rs=DBHelper.executeQuery(cn, query);
		  
		  
		   
		    return rs;
		 }catch(Exception e)
		 {System.out.println(e);
			 return null;
		 }}










}